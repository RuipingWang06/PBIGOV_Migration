# Power BI Data Collector

This repository is designed to help you retrieve information about Power BI resources using the Power BI REST API and upload the data to an AWS S3 bucket. It contains a Python package for API interactions, scripts for execution, and configuration files for easy setup.

---

## **Repository Structure**
- **`pbigov/`**: A Python package that contains the core functionality for interacting with the Power BI REST API.
- **`main_<resource>.py`**: Scripts to retrieve data about Power BI resources using the REST API and upload it to an AWS S3 bucket.
- **`requirements.txt`**: A file listing the Python dependencies required to create the environment.
- **`config.json`**: A JSON file containing environment-specific information (e.g., API credentials).
- **`offsets.json`**: A JSON file containing UTC offsets for time zones.
- **`activities.xml`**: An XML file containing audit activity events.
- **`scanner_columns.yml`**: A YAML file containing column names for scanner script.

---

## **Setup and Usage**

### **1. Prerequisites**
Before you begin, ensure you have the following:
- Python 3.13 installed
- A valid Power BI account with appropriate API permissions

---

### **2. Installation Steps**

1. **Clone the Repository**
   ```bash
   git clone <repo_url>
   cd <folder>
   ```

2. **Create a Virtual Environment**
   ```bash
   python -m venv venv
   source venv/bin/activate   # On Linux/MacOS
   venv\Scripts\activate      # On Windows
   ```

3. **Install Dependencies**
   Install the required Python packages from the `requirements.txt` file:
   ```bash
   pip install -r requirements.txt
   ```

4. **Set Up Configuration**
   Edit the `config.json` file to include your environment-specific details (e.g., API credentials, tenant ID).

---

### **3. Running the Script**

Run the script by providing the configuration file as an argument:
```bash
python main_<resource>.py config.json
```

The script will:
- Fetch Power BI resource data using the REST API.
- Upload the data to an AWS S3 bucket.

---

## **Project Overview**

### **1. `pbigov/`**
The `pbigov` package contains reusable modules for:
- Authenticating with the Power BI REST API.
- Fetching data from Power BI endpoints.
- Handling common errors and retries.

### **2. `main_<resource>.py`**
A standalone script that:
- Loads configuration from `config.json`.
- Fetches resource data from Power BI.
- Uploads the retrieved data to an AWS S3 bucket.

### **3. `requirements.txt`**
Includes all necessary Python dependencies. Example dependencies:
- `requests`: For making HTTP requests.
- `msal`: For handling authentication via OAuth2.

### **4. `config.json`**
A JSON configuration file containing environment details such as:
- URLs
- API scopes

**Example Configuration**:
```json
{
    "scope": ["https://analysis.windows.net/powerbi/api/.default"],
    "authority_url": "https://login.microsoftonline.com/your-tenant-id"
}
```

---

## **Key Notes**
- Ensure your Power BI account has sufficient API permissions for the operations performed.
- Keep sensitive data, such as client secrets, secure and avoid committing them to version control.

---

## **License**
This repository is intended for internal use only and is not licensed for public distribution.

---

## **Acknowledgments**
- [Microsoft Authentication Library (MSAL)](https://pypi.org/project/msal/) for handling OAuth2 authentication.
- Power BI REST API documentation for reference.