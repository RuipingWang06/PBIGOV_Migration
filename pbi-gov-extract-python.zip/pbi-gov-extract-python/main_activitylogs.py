"""
main_activitylogs.py

Description:
    This script pulls the activity events data for Power BI resources and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_activitylogs.py -c <configuration file> -a <activities file> -s <start date> -e <end date>

Dependencies:
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2025-02-20      Toghrul Jafarov            Initial Version
                Samir Mamedov
--------------------------------------------------------------------------------------------------
"""


import argparse
from datetime import datetime, timedelta
import logging
import os
import xml.etree.ElementTree as ET

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('activitylogs.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan last refresh metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    parser.add_argument(
        "-a",
        "--activities_file",
        type=str,
        default="activities.xml",
        help="Path to the activities file, defaults to activities.xml"
    )
    parser.add_argument(
        "-s",
        "--start_date",
        type=str,
        default="",
        help="Start date in YY-MM-DD format, defaults to yesterday"
    )
    parser.add_argument(
        "-e",
        "--end_date",
        type=str,
        default="",
        help="End date in YY-MM-DD format, defaults to yesterday"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    if not os.path.isfile(args.activities_file):
        parser.error(f"The activities file '{args.activities_file}' does not exist or is not a file.")

    try:
        # Create an Admin instance and acquire activities of interest
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file)
        #activities = [elem.text for elem in ET.parse(args.activities_file).getroot().findall("item")]

        if args.start_date:
            start_date = datetime.strptime(args.start_date, "%Y-%m-%d")
            end_date = datetime.strptime(args.end_date, "%Y-%m-%d")
        else:
            start_date = end_date = (datetime.now() - timedelta(days=1))
        
        # Track time to prevent token expiration
        start_time = datetime.now()
        
        while start_date <= end_date:
            start_datetime = start_date.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
            end_datetime = start_date.replace(hour=23, minute=59, second=59, microsecond=999999).isoformat()[:-3]
            
            # Get events and generate a DataFrame
            events = my_admin.get_activity_events(start_datetime, end_datetime)
            logger.info("Activity events data fetched.")
            events_df = generate_dataframe(events, datetimes=['CreationTime', 'LastRefreshTime'])

            # Upload DataFrame to AWS S3 bucket
            my_admin.upload_dataframe_to_s3(events_df, f'activitylogs_{start_date.date()}', 'json.gz', 'activitylogs')
            logger.info("DataFrame uploaded to AWS S3 bucket.")
            
            start_date += timedelta(days=1)
            
            if datetime.now() - start_time > timedelta(hours=1):
                logger.info("Token expired. Renewing...")
                my_admin = Admin(args.config_file)

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()