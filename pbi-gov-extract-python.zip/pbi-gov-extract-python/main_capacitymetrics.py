"""
main_capacitymetrics.py

Description:
    This script pulls Power BI capacity metrics data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_capacitymetrics.py <configuration file> -q <queries> -d <dataset>

Dependencies:
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2025-06-26      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


import argparse
from datetime import datetime, timedelta
import logging
import os
import re

import yaml

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('capacitymetrics.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan capacity metrics data and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    parser.add_argument(
        "-q",
        "--queries_file",
        type=str,
        default="queries.yml",
        help="Path to the queries file, defaults to queries.yml"
    )
    parser.add_argument(
        "-d",
        "--dataset",
        type=str,
        default="68a97ed4-72b9-4771-9416-6722010b98fb",
        help="Dataset ID, defaults to the ID of current capacity metrics dataset"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The queries file '{args.queries_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file, base_url="https://api.powerbi.com/v1.0/myorg/")
        
        # Get queries
        with open(args.queries_file, 'r') as data:
            queries = yaml.safe_load(data)
            
        # Track time to prevent token expiration
        start_time = datetime.now()
            
        # Get query results, generate DataFrames, and upload to AWS S3 bucket
        for query in queries:
            results = my_admin.datasets_execute_queries(dataset=args.dataset, queries=[{"query":query["query"]}])
            results_df = generate_dataframe(results['results'][0]['tables'][0]['rows'],
                                            rename_columns=lambda s: re.search(r'\[(.*?)\]', s).group(1).upper() if re.search(r'\[(.*?)\]', s) else None)
            my_admin.upload_dataframe_to_s3(results_df, query['name'], 'json.gz', query['name'])
            
            if datetime.now() - start_time > timedelta(hours=1):
                logger.info("Token expired. Renewing...")
                my_admin = Admin(args.config_file, base_url="https://api.powerbi.com/v1.0/myorg/")
        
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()