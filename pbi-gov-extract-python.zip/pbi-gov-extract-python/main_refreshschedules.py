"""
main_refreshschedules.py

Description:
    This script pulls the refresh schedule data for Power BI refreshables and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_refreshschedules.py <configuration file>

Dependencies:
    - pandas: For processing data
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2025-01-31      Toghrul Jafarov            Initial Version
                Samir Mamedov
--------------------------------------------------------------------------------------------------
"""


import argparse
from datetime import datetime, timedelta
import json
import logging
import os

import pandas as pd

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import convert_to_utc, generate_dataframe


# Configure logger
setup_logger('refreshschedules.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan refresh schedules metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    parser.add_argument(
        "-f",
        "--offsets_file",
        type=str,
        default="offsets.json",
        help="Path to the offsets file, defaults to offsets.json"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
        
    if not os.path.isfile(args.offsets_file):
        parser.error(f"The offsets file '{args.offsets_file}' does not exist or is not a file.")
        
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file)
        
        # Get timezone offsets
        with open(args.offsets_file) as data:
            offsets = json.load(data)
        
        # Get capacities
        capacities = my_admin.get_capacities_from_config(args.config_file)
        
        # Track time to prevent token expiration
        start_time = datetime.now()

        # Get refreshables, extract refresh schedules, and generate a DataFrame
        refreshables = []
        for c in capacities:
            refreshables.extend(my_admin.get_refreshables_for_capacity(c))
            
            if datetime.now() - start_time > timedelta(hours=1):
                logger.info("Token expired. Renewing...")
                my_admin = Admin(args.config_file)

        logger.info("Refreshables data fetched.")
        refreshables_df = generate_dataframe(refreshables,  drop=['StartTime',
                                                                 'EndTime',
                                                                 'RefreshCount',
                                                                 'RefreshFailures',
                                                                 'AverageDuration',
                                                                 'MedianDuration',
                                                                 'RefreshesPerDay'])
        refreshables_df['CONFIGUREDBY'] = refreshables_df['CONFIGUREDBY'].apply(lambda x: x[0])
        refreshables_df = refreshables_df.loc[:, ~refreshables_df.columns.str.startswith('LASTREFRESH')]
        refreshables_df.rename(columns=lambda x: x[15:] if x.startswith('REFRESHSCHEDULE') else x, inplace=True)
        refreshables_df = refreshables_df.explode('DAYS', ignore_index=True)
        refreshables_df = refreshables_df.explode('TIMES', ignore_index=True)
        refreshables_df[["TIMESUTC", "DAYSUTC", "TIMESUTCDST", "DAYSUTCDST"]] = refreshables_df.apply(lambda row: convert_to_utc(row, offsets), axis=1)
        refreshables_df.fillna(pd.NA, inplace=True)
        logger.info("Refresh schedules extracted.")
          
        # Upload DataFrame to AWS S3 bucket
        my_admin.upload_dataframe_to_s3(refreshables_df, 'refreshschedules', 'json.gz', 'refreshschedules')
        logger.info("DataFrame uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()