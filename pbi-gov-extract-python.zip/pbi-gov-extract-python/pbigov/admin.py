"""
admin.py
Module for administrative operations in the pbigov package.

This module provides an Admin class for performing administrative tasks related to
Power BI, such as managing apps, users, workspaces, and other resources. It supports
both pre-acquired tokens and internal token acquisition using a configuration.

License: Proprietary - Internal Use Only

Usage:
    # Example 1: Pass a pre-acquired token
    from pbigov.auth import PowerBIAuth
    from pbigov.admin import Admin

    auth = PowerBIAuth(config_path="path/to/config.json")
    token = auth.get_access_token()
    admin = Admin(token=token)
    apps = admin.get_apps()
    print(apps)

    # Example 2: Let Admin handle token acquisition
    admin = Admin(config_path="path/to/config.json")
    apps = admin.get_apps()
    print(apps)

Dependencies:
    - auth.py: For providing token acquisition functionality
    - boto3: For interacting with AWS
    - config.py: For loading configuration settings
    - utils.py: For providing shared utility functions for API interaction
    - pandas: For data processing
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-12-10      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


from datetime import datetime, timedelta
import gzip
from io import BytesIO
import logging
import os
from typing import List, Optional

from pbigov.utils import get_data, post_data

import boto3
import pandas as pd


# Configure logger
logger = logging.getLogger(__name__)


class Admin:
    """
    A class for managing administrative tasks in Power BI.

    Attributes:
        token (str): The access token for Power BI API.
        s3_credentials (dict): The AWS S3 credentials.
        base_url (str): The base URL for administrative API calls.
    """

    def __init__(self, config_path: str = None, token: str = None, base_url: str = "https://api.powerbi.com/v1.0/myorg/admin/") -> None:
        """
        Initializes the Admin class with the required configurations.

        Args:
            config_path (str, optional): Path to the configuration file for token acquisition. Required if token is not provided.
            token (str, optional): Pre-acquired access token. Defaults to None.
            base_url (str): The base URL for administrative API calls. Defaults to Power BI API admin base URL.
            
        Raises:
            ValueError: If neither valid token nor configuration file is passed.
        """
        if token:
            logger.info("Using pre-acquired token for Admin.")
            self.token, self.s3_credentials = self._get_token_credentials_from_config(config_path, 0)
            self.token = token
        elif config_path:
            logger.info("Acquiring token and AWS S3 credentials using configuration file.")
            self.token, self.s3_credentials = self._get_token_credentials_from_config(config_path)
        else:
            raise ValueError("Either a token or configuration file path must be provided.")

        self.base_url = base_url

    def _get_token_credentials_from_config(self, config_path: str, token: int = 1) -> str:
        """
        Acquires access token and AWS S3 credentials using the provided configuration.

        Args:
            config_path (str): Path to the configuration file.
            token (int): Boolean value denoting if token acquisiion is needed.

        Returns:
            (str, dict): The acquired access token and AWS S3 credentials.

        Raises:
            ValueError: If token and/or AWS S3 credentials acquisition fails.
        """
        from pbigov.auth import Auth
        
        try:
            auth = Auth(config_path=config_path)
            if token:
                token = auth.get_access_token()
            logger.info("Token and AWS S3 credentials acquired successfully.")
            return token, auth.s3_credentials
        except Exception as e:
            logger.error("Failed to acquire token and/or AWS S3 credentials from configuration file.", exc_info=True)
            raise ValueError("Token and/or AWS S3 credentials acquisition failed.") from e
        
    def get_app_users(self, app: str = None) -> list:
        """
        Returns a list of users that have access to the specified app.
    
        Args:
            app (str): The app ID to retrieve the users of.
    
        Returns:
            list: A list of users for the Power BI app with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}apps/{app}/users?"
        logger.info(f"Fetching Power BI users for the app {app}.")
        try:
            app_users = get_data(url, self.token, key='value')
            
            if not app_users:
                logger.warning(f"No user for the application {app} retrieved.")
                return app_users
            
            logger.info(f"Successfully retrieved users for the application {app}.")
            return app_users
        except Exception as e:
            logger.error(f"Failed to fetch users for the application {app}.", exc_info=True)
            raise e

    def get_apps(self, top: Optional[int] = 5000) -> list:
        """
        Returns a list of apps in the organization.
    
        Args:
            top (int, optional): The maximum number of items per page. Defaults to 5000.
    
        Returns:
            list: A list of Power BI apps with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}apps?"
        logger.info(f"Fetching Power BI apps with a maximum of {top} items per page.")
        try:
            apps = get_data(url, self.token, top=top, key='value')
            
            if not apps:
                logger.warning("No application data retrieved.")
                return apps
            
            logger.info(f"Successfully retrieved {len(apps)} apps.")
            return apps
        except Exception as e:
            logger.error("Failed to fetch Power BI apps.", exc_info=True)
            raise e
    
    def get_capacity_users(self, capacity: str = None) -> list:
        """
        Returns a list of users that have access to the specified workspace.
    
        Args:
            capacity (str): The capacity ID to retrieve the users of.
    
        Returns:
            list: A list of users for the Power BI capacity with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}capacities/{capacity}/users?"
        logger.info(f"Fetching Power BI users for the capacity {capacity}.")
        try:
            capacity_users = get_data(url, self.token, key='value')
            
            if not capacity_users:
                logger.warning(f"No user for the capacity {capacity} retrieved.")
                return capacity_users
            
            logger.info(f"Successfully retrieved users for the capacity {capacity}.")
            return capacity_users
        except Exception as e:
            logger.error(f"Failed to fetch users for the capacity {capacity}.", exc_info=True)
            raise e
            
    def get_activity_events(
        self,
        start_datetime: str,
        end_datetime: str,
        activity: Optional[str] = None
        ) -> list:
        """
        Returns a list of audit activity events for a tenant.
    
        Args:
            start_datetime (Optional[str]): Start date and time of the window. Must be in ISO 8601 compliant UTC format.
            end_datetime (Optional[str]): End date and time of the window. Must be in ISO 8601 compliant UTC format.
            activity (Optional[str]): Filters the results based on the given activity.
    
        Returns:
            list: A list of audit activity events for a tenant.
    
        Raises:
            ValueError: If valid start and end datetimes are not passed.
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}activityevents?"
        try:
            if start_datetime.endswith("Z"):
                start_datetime.replace("Z", "+00:00")
            dt1 = datetime.fromisoformat(start_datetime)
            if end_datetime.endswith("Z"):
                end_datetime.replace("Z", "+00:00")
            dt2 = datetime.fromisoformat(end_datetime)
            if dt1.date() != dt2.date():
                raise ValueError("Start and end datetimes must be in the same UTC day.")
        except:
            raise ValueError("Both start and end datetimes must be in ISO 8601 compliant UTC format.")        
            
        url += f"&startDateTime='{start_datetime}'&endDateTime='{end_datetime}'"
        if activity:
            url += f"&$filter=Activity eq '{activity}'"
    
        logger.info(f"Fetching audit activity events for {start_datetime[:10]}.")
        try:
            events = []
            response = get_data(url, self.token)
        
            if not response:
                logger.warning("No audit activity data retrieved.")
                return events
            
            events.extend(response['activityEventEntities'])
            last = response['lastResultSet']
            
            # Loop for paginated results
            while not last:
                url = response['continuationUri']
                response = get_data(url, self.token)
                events.extend(response['activityEventEntities'])
                last = response['lastResultSet']
            
            logger.info(f"Successfully retrieved {len(events)} audit activity events for {start_datetime[:10]}.")
            return events
        except Exception as e:
            logger.error("Failed to fetch audit activity events.", exc_info=True)
            raise e
        
    def get_capacities_from_config(self, config_path: str) -> list:
        """
        Acquires list of capacities from the provided configuration.

        Args:
            config_path (str): Path to the configuration file.

        Returns:
            list: A list of Power BI capacity IDs.
        """
        from pbigov.config import get_configuration
        
        config = get_configuration(config_path)
        return config.get("capacities", [])

    def get_capacities(self) -> list:
        """
        Returns a list of capacities for the organization.
    
        Returns:
            list: A list of Power BI capacities with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}capacities?"
        logger.info("Fetching Power BI capacities.")
        try:
            capacities = get_data(url, self.token, key='value')
            
            if not capacities:
                logger.warning("No capacity data retrieved.")
                return capacities
            
            logger.info(f"Successfully retrieved {len(capacities)} capacities.")
            return capacities
        except Exception as e:
            logger.error("Failed to fetch Power BI capacities.", exc_info=True)
            raise e
    
    def get_refreshables(self, expand: Optional[List[str]] = None, top: Optional[int] = 5000) -> list:
        """
        Returns a list of refreshables for the organization within a capacity.
    
        Args:
            expand (Optional[List[str]]): List of data types to expand in the response.
            top (Optional[int]): The maximum number of items per page. Defaults to 5000.
    
        Returns:
            list: A list of Power BI refreshables with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}capacities/refreshables?"
        if expand:
            url += "$expand=" + ','.join(expand)
    
        logger.info("Fetching Power BI refreshables.")
        try:
            refreshables = get_data(url, self.token, top=top, key='value')
            
            if not refreshables:
                logger.warning("No refreshable data retrieved.")
                return refreshables
            
            logger.info(f"Successfully retrieved {len(refreshables)} refreshables.")
            return refreshables
        except Exception as e:
            logger.error("Failed to fetch Power BI refreshables.", exc_info=True)
            raise e
            
    def get_refreshables_for_capacity(
        self,
        capacity: str,
        expand: Optional[List[str]] = None,
        top: Optional[int] = 5000
        ) -> list:
        """
        Returns a list of refreshables for the specified capacity that the user has access to.
    
        Args:
            capacity (str): The capacity ID.
            expand (Optional[List[str]]): List of data types to expand in the response.
            top (Optional[int]): The maximum number of items per page. Defaults to 5000.
    
        Returns:
            list: A list of Power BI refreshables with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}capacities/{capacity}/refreshables?"
        if expand:
            url += "$expand=" + ','.join(expand)
    
        logger.info(f"Fetching Power BI refreshables for the capacity {capacity}.")
        try:
            refreshables = get_data(url, self.token, top=top, key='value')
            
            if not refreshables:
                logger.warning(f"No refreshable data retrieved for the capacity {capacity}.")
                return refreshables
            
            logger.info(f"Successfully retrieved {len(refreshables)} refreshables for the capacity {capacity}.")
            return refreshables
        except Exception as e:
            logger.error(f"Failed to fetch Power BI refreshables for the capacity {capacity}.", exc_info=True)
            raise e
    
    def get_groups(self, expand: Optional[List[str]] = None, top: Optional[int] = 5000) -> list:
        """
        Returns a list of workspaces for the organization.
    
        Args:
            expand (Optional[List[str]]): Accepts a comma-separated list of data types, which will be expanded inline in the response.
                                          Supports users, reports, dashboards, datasets, dataflows, and workbooks.
            top (Optional[int]): The maximum number of items per page. Defaults to 5000.
    
        Returns:
            list: A list of Power BI refreshables with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}groups?"
        if expand:
            url += "$expand=" + ','.join(expand)
    
        logger.info("Fetching Power BI workspaces (groups).")
        try:
            groups = get_data(url, self.token, top=top, key='value')
            
            if not groups:
                logger.warning("No workspace (group) data retrieved.")
                return groups
            
            logger.info(f"Successfully retrieved {len(groups)} workspaces (groups).")
            return groups
        except Exception as e:
            logger.error("Failed to fetch Power BI workspaces (groups).", exc_info=True)
            raise e
    
    def get_pipeline_users(self, pipeline: str = None) -> list:
        """
        Returns a list of users that have access to a specified deployment pipeline.
    
        Args:
            pipeline (str): The pipeline ID to retrieve the users of.
    
        Returns:
            list: A list of users for the Power BI pipeline with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}pipelines/{pipeline}/users?"
        logger.info(f"Fetching Power BI users for the pipeline {pipeline}.")
        try:
            pipeline_users = get_data(url, self.token, key='value')
            
            if not pipeline_users:
                logger.warning(f"No user for the pipeline {pipeline} retrieved.")
                return pipeline_users
            
            logger.info(f"Successfully retrieved users for the pipeline {pipeline}.")
            return pipeline_users
        except Exception as e:
            logger.error(f"Failed to fetch users for the pipeline {pipeline}.", exc_info=True)
            raise e
    
    def get_pipelines(self, expand: Optional[List[str]] = None, top: Optional[int] = 5000) -> list:
        """
        Returns a list of deployment pipelines for the organization.
    
        Args:
            expand (Optional[List[str]]): List of data types to expand in the response.
            top (Optional[int]): The maximum number of items per page. Defaults to 5000.
    
        Returns:
            list: A list of Power BI pipelines with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}pipelines?"
        if expand:
            url += "$expand=" + ','.join(expand)
    
        logger.info("Fetching Power BI pipelines.")
        try:
            pipelines = get_data(url, self.token, top=top, key='value')
            
            if not pipelines:
                logger.warning("No pipeline data retrieved.")
                return pipelines
            
            logger.info(f"Successfully retrieved {len(pipelines)} pipelines.")
            return pipelines
        except Exception as e:
            logger.error("Failed to fetch Power BI pipelines.", exc_info=True)
            raise e
    
    def get_workspaces(
        self,
        modified_since: Optional[str] = None,
        exclude_personal_workspaces: Optional[bool] = True,
        exclude_inactive_workspaces: Optional[bool] = False
    ) -> list:
        """
        Gets a list of workspace IDs in the organization.
    
        Args:
            modified_since (Optional[str]): Last modified date (must be in ISO 8601 compliant UTC format).
            exclude_personal_workspaces (Optional[bool]): Whether to exclude personal workspaces. Defaults to True.
            exclude_inactive_workspaces (Optional[bool]): Whether to exclude inactive workspaces. Defaults to False.
    
        Returns:
            list: A list of dictionaries with Power BI workspace IDs.
    
        Raises:
            ValueError: If the date is not in the range of 30 minutes to 30 days prior to the current time.
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}workspaces/modified?"
        if modified_since:
            date_limit_lower = datetime.now()-timedelta(days=30)
            date_limit_upper = datetime.now()-timedelta(minutes=30)
            since = datetime.strptime(modified_since[:19], "%Y-%m-%dT%H:%M:%S")
            if since < date_limit_lower or since > date_limit_upper:
                raise ValueError("Date must be in the range of 30 minutes to 30 days prior to the current time.")
            url += "&modifiedSince=" + modified_since
        url += "&excludePersonalWorkspaces=" + str(exclude_personal_workspaces)
        url += "&excludeInActiveWorkspaces=" + str(exclude_inactive_workspaces)
    
        logger.info("Fetching Power BI workspaces.")
        try:
            workspaces = get_data(url, self.token)
            
            if not workspaces:
                logger.warning("No workspace retrieved.")
                return workspaces
            
            logger.info(f"Successfully retrieved {len(workspaces)} workspaces.")
            return workspaces
        except Exception as e:
            logger.error("Failed to fetch Power BI workspaces.", exc_info=True)
            raise e
    
    def get_scan_result(self, scan_id) -> dict:
        """
        Gets the scan result for the specified scan.
    
        Args:
            scan_id (str): The scan ID, which is included in the response from the API call that triggered the scan.
    
        Returns:
            dict: A dictionary with metadata of requested workspaces.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}workspaces/scanResult/{scan_id}?"    
        logger.info(f"Acquiring the result of scan {scan_id}.")
        try:
            metadata = get_data(url, self.token)
            logger.info(f"Successfully acquired the result of scan {scan_id}.")
            return metadata
        except Exception as e:
            logger.error(f"Failed to acquire the result of scan {scan_id}.", exc_info=True)
            raise e
    
    def get_scan_status(self, scan_id) -> dict:
        """
        Gets the scan status for the specified scan.
    
        Args:
            scan_id (str): The scan ID, which is included in the response from the API call that triggered the scan.
    
        Returns:
            dict: A dictionary with scan ID, status, creation time information.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}workspaces/scanStatus/{scan_id}?"    
        logger.info(f"Checking the status of scan {scan_id}.")
        try:
            scan = get_data(url, self.token)
            logger.info(f"Checked the status of scan {scan_id} - {scan['status']}.")
            return scan
        except Exception as e:
            logger.error(f"Failed to check the status of scan {scan_id}.", exc_info=True)
            raise e
    
    def post_workspace_info(
        self,
        workspaces: List[str],
        datasource_details: Optional[bool] = True,
        dataset_expressions: Optional[bool] = True,
        dataset_schema: Optional[bool] = True,
        get_artifact_users: Optional[bool] = True,
        lineage: Optional[bool] = True
    ) -> dict:
        """
        Initiates a call to receive metadata for the requested list of workspaces.
    
        Args:
            workspaces (List[str]): The required workspace IDs to be scanned (supports 1 to 100 workspace IDs).
            datasource_details (Optional[bool]): Whether to return data source details. Defaults to True.
            dataset_expressions (Optional[bool]): Whether to return dataset expressions (DAX and Mashup queries). Defaults to True.
            dataset_schema (Optional[bool]): Whether to return dataset schema (tables, columns and measures). Defaults to True.
            get_artifact_users (Optional[bool]): Whether to return user details for a Power BI item (such as a report or a dashboard). Defaults to True.
            lineage (Optional[bool]): Whether to return lineage info (upstream dataflows, tiles, data source IDs). Defaults to True.
    
        Returns:
            dict: A dictionary with scan ID, status, creation time information.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}workspaces/getInfo?"
        url += "datasourceDetails=" + str(datasource_details)
        url += "&datasetExpressions=" + str(dataset_expressions)
        url += "&datasetSchema=" + str(dataset_schema)
        url += "&getArtifactUsers=" + str(get_artifact_users)
        url += "&lineage=" + str(lineage)
    
        logger.info("Initiating a call for workspace metadata.")
        try:
            scan = post_data(url, self.token, {"workspaces":workspaces})
            logger.info(f"Successfully initiated a call for {len(workspaces)} workspaces.")
            return scan
        except Exception as e:
            logger.error("Failed to initiate a call for workspace metadata.", exc_info=True)
            raise e

    def get_gateways(self) -> list:
        """
        Returns a list of gateways in the organization.
    
        Returns:
            list: A list of Power BI gateways with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}gatewayClusters"
        logger.info("Fetching Power BI gateways.")
        try:
            gateways = get_data(url, self.token, key='value')
            
            if not gateways:
                logger.warning("No gateway data retrieved.")
                return gateways
            
            logger.info(f"Successfully retrieved {len(gateways)} gateways.")
            return gateways
        except Exception as e:
            logger.error("Failed to fetch Power BI gateways.", exc_info=True)
            raise e
            
    def dataflows_get_dataflow_transactions(self, group: str = None, dataflow: str = None) -> list:
        """
        Returns a list of transactions for the specified dataflow.
    
        Args:
            dataflow (str): The dataflow ID to retrieve the transations of.
    
        Returns:
            list: A list of transactions for the Power BI dataflow with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}groups/{group}/dataflows/{dataflow}/transactions/"
        logger.info(f"Fetching transactions for the dataflow {dataflow}.")
        try:
            transactions = get_data(url, self.token, key='value')
            
            if not transactions:
                logger.warning(f"No transaction for the dataflow {dataflow} retrieved.")
                return transactions
            
            logger.info(f"Successfully retrieved transactions for the dataflow {dataflow}.")
            return transactions
        except Exception as e:
            logger.error(f"Failed to fetch transactions for the dataflow {dataflow}.", exc_info=True)
            raise e     
            
    def datasets_execute_queries(self, dataset: str = None, queries: list = None) -> list:
        """
        Returns a list of results, one per input query.
    
        Args:
            dataset (str): The dataset ID to execute the queries against.
            queries (list): The list of queries to execute.
    
        Returns:
            list: A list of results, one per input query.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}datasets/{dataset}/executeQueries"
        logger.info(f"Fetching given query results for the dataset {dataset}.")
        try:
            results = post_data(url, self.token, {"queries":queries})
            
            if not results:
                logger.warning(f"No query result for the dataset {dataset} retrieved.")
                return results
            
            logger.info(f"Successfully retrieved given query results for the dataset {dataset}.")
            return results
        except Exception as e:
            logger.error(f"Failed to fetch query results for the dataset {dataset}.", exc_info=True)
            raise e

    def get_domains(self) -> list:
        """
        Returns info for all domains.
    
        Args:
    
        Returns:
            list: A list of domains with their details.
    
        Raises:
            Exception: If the API request fails or returns an error.
        """
        url = f"{self.base_url}domains"
        logger.info("Fetching domains...")
        try:
            domains = get_data(url, self.token, key='domains')
            
            if not domains:
                logger.warning("No domain data retrieved.")
                return domains
            
            logger.info(f"Successfully retrieved {len(domains)} domains.")
            return domains
        except Exception as e:
            logger.error("Failed to fetch domains.", exc_info=True)
            raise e

    def upload_dataframe_to_s3(
        self,
        df: pd.DataFrame,
        base_filename: str = "dataframe",
        filetype: Optional[str] = "json.gz",
        directory: Optional[str] = ".",
        bucket: Optional[str] = None,
        folder: Optional[str] = None
    ) -> str:
        """
        Exports the pandas DataFrame to a file with a timestamped filename and uploads it to an S3 bucket.

        Args:
            df (pd.DataFrame): The DataFrame to upload.
            base_filename (str): The base filename (without extension). Defaults to "dataframe".
            filetype (str): The format for the data to be exported. Supports csv, json, json.gz (default).
            directory (str): The directory where the file will be saved in the root folder in the S3 bucket. Defaults to the current directory.
            bucket (str): The S3 bucket name.
            folder (str): The root folder in the S3 bucket.

        Returns:
            str: The full URI of the uploaded file.

        Raises:
            ValueError: If the DataFrame is empty or file type is not supported.
        """
        full_path = ""
        if df.empty:
            logger.info(f"The DataFrame {base_filename} is empty and cannot be saved.")
        else:
            # Retrieve bucket and folder if not provided
            if not bucket:
                bucket = self.s3_credentials['bucket']
            if not folder:
                folder = self.s3_credentials['folder']
    
            # Generate the timestamp and construct the full filename
            timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
            filename = f"{base_filename}_{timestamp}.{filetype}"
            full_path = os.path.join(folder, directory, filename).replace("\\", "/")
    
            # Initialize AWS client
            try:
                s3_client = boto3.client('s3',
                                         aws_access_key_id=self.s3_credentials['access_key'],
                                         aws_secret_access_key=self.s3_credentials['secret_key'],
                                         verify=False)
            except Exception as e:
                logger.error("Failed to initialize AWS client.", exc_info=True)
                raise e
            
            # Prepare data based on format
            buffer = BytesIO()
            content_type = "application/json"  # Default to JSON content type
            content_encoding = None  # Default: No encoding
        
            if filetype == "json":
                df.to_json(buffer, orient="records", lines=True)
            elif filetype == "csv":
                df.to_csv(buffer, index=False)
                content_type = "text/csv"
            elif filetype == "json.gz":
                json_data = df.to_json(orient="records", lines=True)
                with gzip.GzipFile(fileobj=buffer, mode="wb") as gz_file:
                    gz_file.write(json_data.encode("utf-8"))
                content_encoding = "gzip"
            else:
                raise ValueError("Unsupported file format. Choose from 'json', 'json.gz', or 'csv'.")
            
            # Upload to S3 bucket
            s3_params = {"Bucket": bucket, "Key": full_path, "Body": buffer.getvalue(), "ContentType": content_type}
            if content_encoding:
                s3_params["ContentEncoding"] = content_encoding
            try:
                s3_client.put_object(**s3_params)
                logger.info(f"Successfully uploaded to {full_path}.")
            except Exception as e:
                logger.error(f"Failed to upload the data to {full_path}.", exc_info=True)
                raise e

        return full_path


if __name__ == "__main__":
    # Example usage
    # Option 1: Use a pre-acquired token
    token = "your_access_token"  # Replace with a valid token
    admin = Admin(token=token)

    # Option 2: Use a configuration file to acquire the token
    config_path = "path/to/config.json"
    admin_with_config = Admin(config_path=config_path)

    # Fetch and print Power BI apps
    try:
        apps = admin.get_apps()
        print("Power BI Apps (with token):")
        for app in apps:
            print(app)

        apps_with_config = admin_with_config.get_apps()
        print("Power BI Apps (with config):")
        for app in apps_with_config:
            print(app)
    except Exception as e:
        logger.critical(f"Critical error: {e}")
        print(f"Failed to get apps: {e}")
