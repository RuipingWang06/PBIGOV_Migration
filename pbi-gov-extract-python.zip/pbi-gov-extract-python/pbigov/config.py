"""
config.py
Configuration module for the pbigov package.

This module reads configuration settings from a JSON file, falling back to defaults
if specific settings are missing.

License: Proprietary - Internal Use Only

Usage:
    # Example usage to load and print configuration
    from pbigov.config import get_configuration

    config_path = "path/to/config.json"
    config = get_configuration(config_path)
    print("Base URL:", config["base_url"])

Dependencies:
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-12-10      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


import json
import os
import logging
from typing import Dict


# Set up logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# Default Configuration
DEFAULTS = {
    "base_url": "https://api.powerbi.com/v1.0/myorg/",
    "scope": ["https://graph.microsoft.com/.default"],
    "vault_url": "https://your-vault-name.vault.azure.net/",
    "authority_url": "https://login.microsoftonline.com/your-tenant-id",
    "log_level": "INFO",
}


def load_config_file(config_path: str) -> Dict:
    """
    Loads the configuration from a JSON file.

    Args:
        config_path (str): Path to the configuration file.

    Returns:
        dict: Configuration loaded from the file.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the file is not a valid JSON file.
    """
    if not os.path.exists(config_path):
        logger.error(f"Configuration file not found: {config_path}.")
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    try:
        with open(config_path, "r") as file:
            logger.info(f"Loading configuration from {config_path}")
            config = json.load(file)
            return config
    except json.JSONDecodeError as e:
        logger.error(f"Error parsing the configuration file {config_path}: {e}", exc_info=True)
        raise ValueError(f"Error parsing the configuration file: {e}")


def merge_config(config_file: Dict) -> Dict:
    """
    Merges the loaded configuration with the defaults.

    Args:
        config_file (dict): Configuration loaded from the file.

    Returns:
        dict: Merged configuration.
    """
    config = DEFAULTS.copy()
    config.update(config_file)  # Override defaults with file values
    
    # Log the final configuration for debugging
    logger.debug("Final configuration after merging defaults and file values:")
    for key, value in config.items():
        logger.debug(f"{key}: {value}")
    
    return config


def get_configuration(config_path: str) -> Dict:
    """
    Retrieves the configuration, loading it from a file and merging it with defaults.

    Args:
        config_path (str): Path to the configuration file.

    Returns:
        dict: Final merged configuration.
    """
    file_config = load_config_file(config_path)
    config = merge_config(file_config)

    return config


if __name__ == "__main__":
    # Example usage
    config_path = "config.json"  # Update this path as needed
    try:
        config = get_configuration(config_path)
        print("Configuration:")
        for key, value in config.items():
            print(f"{key}: {value}")
    except Exception as e:
        logger.critical(f"Critical error: {e}")
        print(f"Failed to get configuration: {e}")
