"""
utils.py

Description:
    This is a utility module for the pbigov package which provides shared utility functions.

License: Proprietary - Internal Use Only

Usage:
    from pbigov.utils import get_data, post_data

Dependencies:
    - requests: For sending HTTP requests
    - pandas: For data processing
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-12-10      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


from datetime import datetime, timedelta
import logging
import os
import re
from typing import Any, Callable, Dict, List, Optional, Union

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# Configure logger
logger = logging.getLogger(__name__)


DEFAULT_RETRY = 5
DEFAULT_BACKOFF = 10


def camel_to_pascal(s: str) -> str:
    """
    Converts a camelCase string to PascalCase.

    Args:
        s (str): The camelCase string to convert.

    Returns:
        str: The converted string in PascalCase.
    """
    # Check for empty input
    if not s:
        return ""
    # Capitalize the first symbol
    pascal_case = s[0].upper() + s[1:]
    return pascal_case


def camel_to_title(s: str) -> str:
    """
    Converts a camelCase string to Title Case.

    Args:
        s (str): The camelCase string to convert.

    Returns:
        str: The converted string in Title Case.
    """
    # Insert a space before each uppercase letter preceded by a lowercase letter
    spaced = re.sub(r'([a-z])([A-Z])', r'\1 \2', s)
    # Capitalize the first symbol of each word
    title_case = ' '.join(word.capitalize() for word in spaced.split())
    return title_case


def camel_to_upper(s: str) -> str:
    """
    Converts a camelCase string to UPPERCASE.

    Args:
        s (str): The camelCase string to convert.

    Returns:
        str: The converted string in UPPERCASE.
    """
    # Capitalize all symbols
    upper_case = s.upper()
    return upper_case


def format_datetime(iso_string: str) -> Optional[str]:
    """
    Converts an ISO 8601 datetime string to 'YYYY-MM-DD HH:MM:SS' format.

    Args:
        iso_string (str): The input ISO 8601 datetime string.

    Returns:
        Optional[str]: The converted datetime string in 'YYYY-MM-DD HH:MM:SS' format,
                       or None if the input is invalid.
    """
    try:
        # Parse the ISO 8601 string
        dt = datetime.fromisoformat(iso_string)
        
        # Convert to the desired format
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError as e:
        # Handle invalid input format
        print(f"Invalid ISO 8601 datetime string: {iso_string}. Error: {e}")
        return None


def send_request(
    method: str,
    url: str,
    headers: Optional[Dict[str, str]] = None,
    data: Optional[Any] = None,
    retry: Optional[int] = None,
    backoff: Optional[int] = None,
    timeout: Optional[Union[float, tuple]] = (10, None)
) -> requests.Response:
    """
    Sends an HTTP request to the specified URL with the given parameters.

    Args:
        method (str): HTTP method ('GET', 'POST', etc.).
        url (str): The API endpoint to send the request to.
        headers (Optional[Dict[str, str]]): Request headers.
        data (Optional[Any]): JSON-serializable request payload.
        retry (Optional[int]): Total number of retry attempts, default is None.
        backoff (Optional[int]): Initial wait time before first retry, default is None.
        timeout (float | tuple): Timeout in seconds, default is (10, None), can be float or (connect, read).

    Returns:
        requests.Response: The HTTP response object.

    Raises:
        requests.RequestException: If the request fails after all retries.
    """
    session = requests.Session()

    retry_strategy = Retry(
        total=retry or DEFAULT_RETRY,
        backoff_factor=backoff or DEFAULT_BACKOFF,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=False,  # Retry all methods (including POST) — use with caution
        raise_on_status=False,
    )

    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    try:
        # Dispatch the request
        response = session.request(method=method, url=url, headers=headers, json=data, timeout=timeout)
        return response
    except requests.RequestException as e:
        logger.error(f"Request failed: {method} {url} — {e}", exc_info=True)
        raise


def get_data(url: str, token: str, top: Optional[int] = None, key: Optional[str] = None) -> Union[list, dict]:
    """
    Makes a GET request to the specified URL using the provided token and handles pagination for large result sets.

    Args:
        url (str): The API endpoint URL.
        token (str): The access token for authentication.
        top (Optional[int]): The requested number of items to fetch.
        key (Optional[str]): The key to extract the data from the response.

    Returns:
        Union[list, dict]: The JSON response from the API as a list or dictionary of objects.

    Raises:
        ValueError: If the API URL or access token is invalid.
        requests.exceptions.RequestException: For network-related errors or invalid API responses.
    """
    # Validate input parameters
    if not url or not token:
        raise ValueError("Both urls and access token must be provided and non-empty.")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    results = []
    
    # Check if pagination needed
    if top:
        skip = 0
        while True:
            try:
                # Make the API request
                logger.info(f"Fetching data with top={top} and skip={skip}...")

                response = send_request("GET", url+f"&$top={top}&$skip={skip}", headers=headers)
                response.raise_for_status()
    
                # Parse the JSON response
                data = response.json()
                if key:
                    data = data[key]
    
                # Check if data is empty (end of dataset)
                if not data:
                    logger.info("No more data to fetch. Stopping pagination.")
                    break
    
                # Append the fetched data to the result
                results.extend(data)
    
                # Increment the skip value by the actual number of rows returned
                skip += len(data)
    
            except requests.RequestException as e:
                logger.error(f"Error while fetching data: {e}", exc_info=True)
                break
    else:
        try:
            # Make the API request
            logger.info("Fetching data...")
    
            response = send_request("GET", url, headers=headers)
            response.raise_for_status()
    
            # Parse the JSON response
            results = response.json()
            if key:
                results = results[key]

        except requests.RequestException as e:
            logger.error(f"Error while fetching data: {e}", exc_info=True)

    logger.info(f"Fetched a total of {len(results)} instances.")
    return results


def post_data(url: str, token: str, body: dict) -> list:
    """
    Makes a POST request to the specified URL using the provided token.

    Args:
        url (str): The API endpoint URL.
        token (str): The access token for authentication.
        body (dict): The data to post.

    Returns:
        list: The JSON response from the API as a list of objects.

    Raises:
        ValueError: If the API URL or access token is invalid.
        requests.exceptions.RequestException: For network-related errors or invalid API responses.
    """
    # Validate input parameters
    if not url or not token:
        raise ValueError("Url, access token, and body must be provided and non-empty.")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    result = None
    
    try:
        # Make the API request
        logger.info("Posting data...")

        response = send_request("POST", url, headers=headers, data=body)
        response.raise_for_status()

        # Parse the JSON response
        result = response.json()
        logger.info("Posted data.")
        
    except requests.RequestException as e:
        logger.error(f"Error while posting data: {e}", exc_info=True)

    return result


def convert_to_utc(row: pd.Series, offsets: Dict[str, Dict[str, Any]]) -> pd.Series:
    """
    Converts local time to UTC and adjusts the weekday, handling DST if applicable.

    Args:
        row (pd.Series): A pandas Series representing a row of a DataFrame.
                         Expected to contain 'Times', 'Days', and 'LocalTimeZoneId'.
        offsets (Dict[str, Dict[str, Any]]): A dictionary mapping timezone IDs to their offset and DST values.

    Returns:
        pd.Series: A Series containing:
            - Converted time without DST adjustment
            - Updated day without DST adjustment
            - Converted time with DST adjustment (if applicable)
            - Updated day with DST adjustment (if applicable)
    """
    weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    time_str = row.get("TIMES")
    day = row.get("DAYS")
    timezone_id = row.get("LOCALTIMEZONEID")

    # Validate input
    if pd.isna(time_str) or pd.isna(day) or not timezone_id:
        return pd.Series([time_str, day, pd.NA, pd.NA])

    # Find the timezone entry
    tz_entry = offsets.get(timezone_id)
    if not tz_entry:
        return pd.Series([time_str, day, pd.NA, pd.NA])

    try:
        # Convert time string to datetime object
        original_time = datetime.strptime(time_str, "%H:%M")
        base_offset = tz_entry["Offset"]

        # Convert to UTC without DST
        new_time = original_time - timedelta(minutes=base_offset)
        new_day = day
        if new_time.day > original_time.day:
            new_day = weekdays[(weekdays.index(day) + 1) % 7]  # Next day
        elif new_time.day < original_time.day:
            new_day = weekdays[(weekdays.index(day) - 1) % 7]  # Previous day

        # Handle DST adjustment
        if tz_entry["DST"]:
            dst_time = new_time - timedelta(minutes=60)
            if dst_time.day > new_time.day:
                dst_day = weekdays[(weekdays.index(new_day) + 1) % 7]  # Next day for DST
            elif dst_time.day < new_time.day:
                dst_day = weekdays[(weekdays.index(new_day) - 1) % 7]  # Previous day for DST
            else:
                dst_day = new_day
        else:
            dst_time, dst_day = pd.NA, pd.NA  # No DST adjustment

        return pd.Series([new_time.strftime("%H:%M"), new_day, dst_time.strftime("%H:%M") if pd.notna(dst_time) else pd.NA, dst_day])

    except (ValueError, KeyError) as e:
        logger.error(f"An error occurred while converting to UTC: {e}", exc_info=True)
        return pd.Series([time_str, day, pd.NA, pd.NA])


def generate_dataframe(
    data: Union[List[Dict], pd.DataFrame],
    columns: Optional[List[str]] = None,
    drop: Optional[List[str]] = None,
    datetimes: Optional[List[str]] = None,
    rename_columns: Optional[Union[Dict[str, str], Callable[[str], str]]] = camel_to_upper,
) -> pd.DataFrame:
    """
    Generates a pandas DataFrame from a list of dictionaries with optional column filtering, exclusion, formatting, and renaming.
    When given a pandas DataFrame, skips the generation part.

    Args:
        data (Union[List[Dict], pd.DataFrame]): The input data as a list of dictionaries or a pandas DataFrame.
        columns (Optional[List[str]]): A list of columns to include in the DataFrame.
        drop (Optional[List[str]]): A list of columns to exclude from the DataFrame.
        datetimes (Optional[List[str]]): A list of datetime columns to format.
        rename_columns (Optional[Union[Dict[str, str], Callable[[str], str]]]):
            - If a dictionary is provided, it maps old column names to new names.
            - If a callable function is provided, it is applied to each column name for transformation.
            - Defaults to camel_to_pascal

    Returns:
        pd.DataFrame: The resulting pandas DataFrame.

    Raises:
        ValueError: If the input data is not a list of dictionaries or if specified columns are invalid.
    """
    if not ((isinstance(data, list) and all(isinstance(row, dict) for row in data)) or isinstance(data, pd.DataFrame)):
        raise ValueError("Input data must be a list of dictionaries or a pandas DataFrame.")
        
    # Create the initial DataFrame
    df = pd.json_normalize(data) if not isinstance(data, pd.DataFrame) else data
    
    # Convert normalized column names to PascalCase
    df.rename(columns=lambda x: ''.join(t[0].upper()+t[1:] for t in x.split('.')), inplace=True)
    
    if not df.empty:
        # Filter columns to keep
        if columns:
            try:
                df = df[columns]
            except KeyError as e:
                raise ValueError(f"Some specified columns are not in the data: {e}")
        elif drop:
            # Drop the columns to exclude if specified
            df.drop(columns=drop, inplace=True, errors="ignore")
        
        # Replace missing values with pandas NA
        df.fillna(pd.NA, inplace=True)
        
        # Format datetime columns if specified
        if datetimes:
            try:
                df.loc[:, datetimes] = df[datetimes].map(format_datetime, na_action='ignore')
            except KeyError as e:
                raise ValueError(f"Some specified datetime columns are not in the data: {e}")
        
        # Rename columns if specified
        if rename_columns:
            try:
                df.rename(columns=rename_columns, inplace=True)
            except KeyError as e:
                raise ValueError(f"Some columns to rename are not in the data: {e}")
            
        # Drop rows with all values missing and duplicate rows
        df.dropna(how='all', inplace=True)
        df = df[~df.astype(str).duplicated()]
        df["EXTRACTEDON"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    return df


def save_dataframe(
    df: pd.DataFrame,
    base_filename: str = "dataframe",
    filetype: str = "csv",
    directory: str = "."
) -> str:
    """
    Saves a pandas DataFrame to a file with a timestamped filename.

    Args:
        df (pd.DataFrame): The DataFrame to save.
        base_filename (str): The base filename (without extension). Defaults to "dataframe".
        filetype (str): The format for the data to be exported. Supports csv (default), json, json.gz.
        directory (str): The directory where the file will be saved. Defaults to the current directory.

    Returns:
        str: The full path of the saved file.

    Raises:
        ValueError: If the DataFrame is empty.
        OSError: If the directory does not exist and cannot be created.
    """
    full_path = ""
    if df.empty:
        logger.info(f"The DataFrame {base_filename} is empty and cannot be saved.")
    else:
        # Ensure the directory exists
        os.makedirs(directory, exist_ok=True)
    
        # Generate the timestamp and construct the full filename
        timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
        filename = f"{base_filename}_{timestamp}.{filetype}"
        full_path = os.path.join(directory, filename)
    
        # Save the DataFrame to a file
        if filetype == "csv":
            df.to_csv(full_path, index=False, encoding='utf-8')
        else:
            df.to_json(full_path, orient='records', lines=True)

    return full_path