"""
logger.py

This module provides a centralized logger configuration for applications.
It sets up logging with both file and console handlers, supports log rotation,
and ensures consistency across all modules in the application.

Author: Samir Mamedov
Email: samir_mamedov@jabil.com
Version: 1.0.0
Date: 2025-01-22
License: Proprietary - Internal Use Only

Usage:

Dependencies:

"""


import logging
from logging.handlers import RotatingFileHandler
import sys


def setup_logger(log_file: str, log_level: int = logging.DEBUG) -> None:
    """
    Sets up a centralized logger configuration for the application.

    Args:
        log_file (str): Path to the log file.
        log_level (Optional[int]): Logging level (default: logging.DEBUG).

    Returns:
        None
    """
    try:
        # Create the root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(log_level)

        # Create a file handler with log rotation
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=5 * 1024 * 1024,  # Maximum file size (5 MB)
            backupCount=3              # Keep up to 3 backup files
        )
        file_handler.setLevel(log_level)

        # Create a console handler for optional console output
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)

        # Define a log format
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        formatter = logging.Formatter(log_format)
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Add handlers to the root logger
        root_logger.addHandler(file_handler)
        root_logger.addHandler(console_handler)

    except Exception as e:
        # Fallback to stderr if logging setup fails
        print(f"Failed to configure logging: {e}", file=sys.stderr)