"""
auth.py
Module for handling authentication with the Power BI REST API and AWS.

This module retrieves client credentials from a configuration file using the
`load_config` function from the `config.py` module and uses MSAL to acquire
an access token using OAuth2 flow.

License: Proprietary - Internal Use Only

Usage:
    from pbigov.auth import Auth

    auth = Auth(config_path="path/to/config.json")
    token = auth.get_access_token()
    print(f"Access Token: {token}")

Dependencies:
    - azure-keyvault-secrets: For accessing Azure Key Vault
    - azure-identity: For authenticating to Azure Key Vault
    - config.py: For loading configuration settings
    - msal: For handling OAuth2 authentication flow
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-12-10      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


import logging

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from msal import PublicClientApplication

from pbigov.config import get_configuration


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
    """Custom exception for authentication-related errors."""
    pass


class VaultError(Exception):
    """Custom exception for vault-related errors."""
    pass


class Auth:
    """
    Handles authentication with Power BI and AWS.

    Attributes:
        config (dict): The loaded configuration settings.
        authority_url (str): The authority URL for Azure AD authentication.
        scope (list[str]): The list of scopes for the API access.
        vault_url (str): URL of the Azure Key Vault containing the credentials.
        client_id (str): The client ID Power BI authentication.
        username (str): The username for Power BI authentication.
        password (str): The password for Power BI authentication.
        s3_credentials (dict): The credentials for AWS S3 interaction.
    """

    def __init__(self, config_path: str) -> None:
        """
        Initializes the Auth instance with a configuration file.

        Args:
            config_path (str): Path to the JSON configuration file.
        """
        self.config = get_configuration(config_path)
        self.authority_url = self.config.get("authority_url")
        self.scope = self.config.get("scope", [])
        self.vault_url = self.config.get("vault_url")
        
        self.client_id = None
        self.username = None
        self.password = None
        self.s3_credentials = {}

        self._validate_config()
        self._retrieve_credentials()

    def _validate_config(self) -> None:
        """Validates the provided configuration."""
        missing_fields = [
            key for key in ["authority_url", "vault_url"]
            if not getattr(self, key)
        ]
        if missing_fields:
            raise ValueError(f"Missing required configuration fields: {', '.join(missing_fields)}")

    def _retrieve_credentials(self) -> None:
        """
        Retrieves all needed credentials from Azure Key Vault.

        Raises:
            VaultError: If credentials cannot be retrieved.
        """
        logger.info("Connecting to Azure Key Vault to retrieve credentials.")
        try:
            credential = DefaultAzureCredential()
            client = SecretClient(vault_url=self.vault_url, credential=credential)

            self.client_id = client.get_secret("AzureADapp-ClientId").value
            self.username = client.get_secret("PBI-Admin-User").value
            self.password = client.get_secret("PBI-Admin-Password").value
            self.s3_credentials['access_key'] = client.get_secret("AWSS3-AccessKey").value
            self.s3_credentials['secret_key'] = client.get_secret("AWSS3-SecretKey").value
            self.s3_credentials['bucket'] = client.get_secret("AWSS3-BucketName").value
            self.s3_credentials['folder'] = client.get_secret("AWSS3-PBIFolderPath").value

            logger.info("Successfully retrieved credentials from Azure Key Vault.")
        except Exception as e:
            logger.error("Failed to retrieve credentials from Azure Key Vault.", exc_info=True)
            raise VaultError(f"Error retrieving credentials from vault: {e}")

    def get_access_token(self) -> str:
        """
        Acquires an access token using the loaded configuration.

        Returns:
            str: The access token for Power BI API requests.

        Raises:
            AuthenticationError: If the authentication fails.
        """
        logger.info("Initializing MSAL PublicClientApplication.")
        app = PublicClientApplication(
            client_id=self.client_id,
            authority=self.authority_url
        )

        logger.info("Attempting to acquire token for user.")
        try:
            result = app.acquire_token_by_username_password(
                username=self.username,
                password=self.password,
                scopes=self.scope
            )
        except Exception as e:
            logger.error("Error during token acquisition.", exc_info=True)
            raise AuthenticationError(f"An error occurred while acquiring the token: {e}")

        if "access_token" in result:
            logger.info("Token acquisition successful.")
            return result["access_token"]

        # Handle cases where authentication fails but doesn't raise an exception
        error_message = result.get("error_description", "Unknown error occurred.")
        logger.error(f"Authentication failed: {error_message}")
        raise AuthenticationError(f"Authentication failed: {error_message}")


if __name__ == "__main__":
    # Example usage
    try:
        config_path = "path/to/config.json"
        auth = Auth(config_path=config_path)
        token = auth.get_access_token()
        print(f"Access Token: {token}")
    except Exception as e:
        logger.critical(f"Critical error: {e}")
        print(f"Failed to authenticate: {e}")
