"""
main_scanner.py

Description:
    This script pulls Power BI workspaces data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_scanner.py -c <configuration file> -m <mode> -s <since>

Dependencies:
    - pandas: For processing data
    - pyyaml: For managing YAML files
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-11-25      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


import argparse
from datetime import datetime, timedelta
import json
import logging
import os
import time
from typing import List

import pandas as pd
import yaml

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import convert_to_utc, generate_dataframe


# Configure logger
setup_logger('scanner.log')
logger = logging.getLogger(__name__) # Logger for the current script


# 100 is the limit of workspaces per request
CHUNK_SIZE = 100


def freeze_columns(df: pd.DataFrame, required_columns: List[str]) -> pd.DataFrame:
    """
    Ensures the DataFrame has exactly the specified columns

    Args:
        df (pd.DataFrame): The input DataFrame.
        required_columns (List[str]): List of column names to enforce.

    Returns:
        pd.DataFrame: A new DataFrame with exactly the required columns.
    """
    # Add missing columns with pd.NA
    for col in required_columns:
        if col not in df.columns:
            df[col] = pd.NA

    # Filter to only required columns and reorder
    return df[required_columns].copy()


def main():
    """
    Main function to scan workspaces metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    parser.add_argument(
        "-o",
        "--columns_file",
        type=str,
        default="scanner_columns.yml",
        help="Path to the columns file, defaults to scanner_columns.yml"
    )
    parser.add_argument(
        "-f",
        "--offsets_file",
        type=str,
        default="offsets.json",
        help="Path to the offsets file, defaults to offsets.json"
    )
    parser.add_argument(
        "-m",
        "--mode",
        type=str,
        default="incremental",
        help="Mode - full or incremental"
    )
    parser.add_argument(
        "-s",
        "--since",
        type=str,
        default=f"{(datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')}",
        help="Modified since date in YY-MM-DD format, defaults to yesterday"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    if not os.path.isfile(args.columns_file):
        parser.error(f"The columns file '{args.columns_file}' does not exist or is not a file.")
    
    if not os.path.isfile(args.offsets_file):
        parser.error(f"The offsets file '{args.offsets_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        
        my_admin = Admin(args.config_file)
        
        # Get columns names to freeze
        with open(args.columns_file) as data:
            columns = yaml.safe_load(data)
            
        # Get timezone offsets
        with open(args.offsets_file) as data:
            offsets = json.load(data)
        
        # Get workspaces and create chunks for scans
        if args.mode == "full":
            workspaces_list = [w['id'] for w in my_admin.get_workspaces()]
        elif args.mode == "incremental":
            since_date = datetime.strptime(args.since, "%Y-%m-%d")
            since_datetime = since_date.replace(hour=0, minute=0, second=0, microsecond=0).isoformat() + ".0000000Z"
            workspaces_list = [w['id'] for w in my_admin.get_workspaces(since_datetime)]
        else:
            parser.error("The mode can be either full or incremental.")
        
        logger.info(f"{len(workspaces_list)} workspaces fetched.")
        
        workspace_chunks = [workspaces_list[i:i + CHUNK_SIZE] for i in range(0, len(workspaces_list), CHUNK_SIZE)] 
        
        # Track time to prevent token expiration
        start_time = datetime.now()
        
        # Scan workspaces data
        workspaces, datasources = [], []
        for i in range (len(workspace_chunks)):
            logger.info(f"Scanning workspaces {i*100+1} - {i*100+len(workspace_chunks[i])}...")
            
            response = my_admin.post_workspace_info(workspace_chunks[i])
            scan_id = response.get('id')

            status = my_admin.get_scan_status(scan_id)['status']
            while status != "Succeeded":
                time.sleep(10)
                status = my_admin.get_scan_status(scan_id)['status']
            metadata = my_admin.get_scan_result(scan_id)
            
            workspaces.extend(metadata.get('workspaces', []))
            datasources.extend(metadata.get('datasourceInstances', []))
            
            if datetime.now() - start_time > timedelta(hours=1):
                logger.info("Token expired. Renewing...")
                my_admin = Admin(args.config_file)

        logger.info(f"{len(workspaces_list)} workspaces data scanned. Generating DataFrames...")
        
        # Generate DataFrames and upload to AWS S3 bucket
        workspaces_df = generate_dataframe(workspaces)
        datasources_df = generate_dataframe(datasources, rename_columns=lambda x: ''.join(x.upper().split('DETAILS')))
        datasources_df = datasources_df.rename(columns={'CONNECTIONCONNECTIONSTRING':'CONNECTIONSTRING'})
        
        if 'DATARETRIEVALSTATE' in workspaces_df:
            logger.info("Workspaces by DATARETRIEVALSTATE:")
            logger.info(f"{workspaces_df['DATARETRIEVALSTATE'].value_counts()}")
        
        datasources_df = freeze_columns(datasources_df, columns['datasources'])
        my_admin.upload_dataframe_to_s3(datasources_df, 'datasources_scan', 'json.gz', 'datasources_scan')
        
        if 'USERS' in workspaces_df.columns and workspaces_df['USERS'].any():
            workspace_users_df = workspaces_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
            workspace_users_df = pd.concat([workspace_users_df['ID'], pd.json_normalize(workspace_users_df['USERS'])], axis=1)
            workspace_users_df = workspace_users_df.rename(columns={'ID':'WORKSPACEID', 'groupUserAccessRight':'ACCESSRIGHT'})
            workspace_users_df = generate_dataframe(workspace_users_df)
            workspace_users_df.dropna(subset=[c for c in workspace_users_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['USERS'], inplace=True)
            
            workspace_users_df = freeze_columns(workspace_users_df, columns['workspaceusers'])
            my_admin.upload_dataframe_to_s3(workspace_users_df, 'workspaceusers_scan', 'json.gz', 'workspaceusers_scan')
        else:
            logger.info("No workspace users data extracted.")

        if 'ENVIRONMENT' in workspaces_df.columns and workspaces_df['ENVIRONMENT'].any():
            environments_df = workspaces_df[['ID', 'ENVIRONMENT']].explode('ENVIRONMENT', ignore_index=True)
            environments_df = pd.concat([environments_df['ID'], pd.json_normalize(environments_df['ENVIRONMENT'])], axis=1)
            environments_df = environments_df.rename(columns={'ID':'WORKSPACEID'})
            environments_df = generate_dataframe(environments_df)
            environments_df.dropna(subset=[c for c in environments_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['ENVIRONMENT'], inplace=True)
        
            if 'USERS' in environments_df.columns and environments_df['USERS'].any():
                environment_users_df = environments_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                environment_users_df = pd.concat([environment_users_df['ID'], pd.json_normalize(environment_users_df['USERS'])], axis=1)
                environment_users_df = environment_users_df.rename(columns={'ID':'ENVIRONMENTID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                environment_users_df = generate_dataframe(environment_users_df)
                environment_users_df.dropna(subset=[c for c in environment_users_df.columns if c!='ENVIRONMENTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                environments_df.drop(columns=['USERS'], inplace=True)
                
                environment_users_df = freeze_columns(environment_users_df, columns['environmentusers'])
                my_admin.upload_dataframe_to_s3(environment_users_df, 'environmentusers_scan', 'json.gz', 'environmentusers_scan')
            else:
                logger.info("No environment users data extracted.")
            
            environments_df = freeze_columns(environments_df, columns['environments'])
            my_admin.upload_dataframe_to_s3(environments_df, 'environments_scan', 'json.gz', 'environments_scan')
        else:
            logger.info("No environment data extracted.")

        if 'EVENTHOUSE' in workspaces_df.columns and workspaces_df['EVENTHOUSE'].any():            
            eventhouses_df = workspaces_df[['ID', 'EVENTHOUSE']].explode('EVENTHOUSE', ignore_index=True)
            eventhouses_df = pd.concat([eventhouses_df['ID'], pd.json_normalize(eventhouses_df['EVENTHOUSE'])], axis=1)
            eventhouses_df = eventhouses_df.rename(columns={'ID':'WORKSPACEID'})
            eventhouses_df = generate_dataframe(eventhouses_df)
            eventhouses_df.dropna(subset=[c for c in eventhouses_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['EVENTHOUSE'], inplace=True)
            
            if 'USERS' in eventhouses_df.columns and eventhouses_df['USERS'].any():
                eventhouse_users_df = eventhouses_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                eventhouse_users_df = pd.concat([eventhouse_users_df['ID'], pd.json_normalize(eventhouse_users_df['USERS'])], axis=1)
                eventhouse_users_df = eventhouse_users_df.rename(columns={'ID':'EVENTHOUSEID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                eventhouse_users_df = generate_dataframe(eventhouse_users_df)
                eventhouse_users_df.dropna(subset=[c for c in eventhouse_users_df.columns if c!='EVENTHOUSEID' and c!='EXTRACTEDON'], how='all', inplace=True)
                eventhouses_df.drop(columns=['USERS'], inplace=True)
                
                eventhouse_users_df = freeze_columns(eventhouse_users_df, columns['eventhouseusers'])
                my_admin.upload_dataframe_to_s3(eventhouse_users_df, 'eventhouseusers_scan', 'json.gz', 'eventhouseusers_scan')
            else:
                logger.info("No eventhouse users data extracted.")
            
            eventhouses_df = freeze_columns(eventhouses_df, columns['eventhouses'])
            my_admin.upload_dataframe_to_s3(eventhouses_df, 'eventhouses_scan', 'json.gz', 'eventhouses_scan')
        else:
            logger.info("No eventhouse data extracted.")
        
        if 'EVENTSTREAM' in workspaces_df.columns and workspaces_df['EVENTSTREAM'].any():
            eventstreams_df = workspaces_df[['ID', 'EVENTSTREAM']].explode('EVENTSTREAM', ignore_index=True)
            eventstreams_df = pd.concat([eventstreams_df['ID'], pd.json_normalize(eventstreams_df['EVENTSTREAM'])], axis=1)
            eventstreams_df = eventstreams_df.rename(columns={'ID':'WORKSPACEID',
                                                              'extendedProperties.EventStreamVersion':'VERSION',
                                                              'extendedProperties.EnableEventStreamApiV2':'ENABLEEVENTSTREAMAPIV2'})
            eventstreams_df = generate_dataframe(eventstreams_df)
            eventstreams_df.dropna(subset=[c for c in eventstreams_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['EVENTSTREAM'], inplace=True)
            
            if 'USERS' in eventstreams_df.columns and eventstreams_df['USERS'].any():
                eventstream_users_df = eventstreams_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                eventstream_users_df = pd.concat([eventstream_users_df['ID'], pd.json_normalize(eventstream_users_df['USERS'])], axis=1)
                eventstream_users_df = eventstream_users_df.rename(columns={'ID':'EVENTSTREAMID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                eventstream_users_df = generate_dataframe(eventstream_users_df)
                eventstream_users_df.dropna(subset=[c for c in eventstream_users_df.columns if c!='EVENTSTREAMID' and c!='EXTRACTEDON'], how='all', inplace=True)
                eventstreams_df.drop(columns=['USERS'], inplace=True)
                
                eventstream_users_df = freeze_columns(eventstream_users_df, columns['eventstreamusers'])
                my_admin.upload_dataframe_to_s3(eventstream_users_df, 'eventstreamusers_scan', 'json.gz', 'eventstreamusers_scan')
            else:
                logger.info("No eventstream users data extracted.")
            
            eventstreams_df = freeze_columns(eventstreams_df, columns['eventstreams'])
            my_admin.upload_dataframe_to_s3(eventstreams_df, 'eventstreams_scan', 'json.gz', 'eventstreams_scan')
        else:
            logger.info("No eventstream data extracted.")
        
        if 'EXPLORATION' in workspaces_df.columns and workspaces_df['EXPLORATION'].any():
            explorations_df = workspaces_df[['ID', 'EXPLORATION']].explode('EXPLORATION', ignore_index=True)
            explorations_df = pd.concat([explorations_df['ID'], pd.json_normalize(explorations_df['EXPLORATION'])], axis=1)
            explorations_df = explorations_df.rename(columns={'ID':'WORKSPACEID', 'lastUpdatedDate':'LASTUPDATEDDATETIME', 'createdDate':'CREATEDDATETIME'})
            explorations_df = generate_dataframe(explorations_df, datetimes=['LASTUPDATEDDATETIME', 'CREATEDDATETIME'])
            explorations_df.dropna(subset=[c for c in explorations_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['EXPLORATION'], inplace=True)
            
            if 'USERS' in explorations_df.columns and explorations_df['USERS'].any():
                exploration_users_df = explorations_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                exploration_users_df = pd.concat([exploration_users_df['ID'], pd.json_normalize(exploration_users_df['USERS'])], axis=1)
                exploration_users_df = exploration_users_df.rename(columns={'ID':'EXPLORATIONID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                exploration_users_df = generate_dataframe(exploration_users_df)
                exploration_users_df.dropna(subset=[c for c in exploration_users_df.columns if c!='EXPLORATIONID' and c!='EXTRACTEDON'], how='all', inplace=True)
                explorations_df.drop(columns=['USERS'], inplace=True)
                
                exploration_users_df = freeze_columns(exploration_users_df, columns['explorationusers'])
                my_admin.upload_dataframe_to_s3(exploration_users_df, 'explorationusers_scan', 'json.gz', 'explorationusers_scan')
            else:
                logger.info("No exploration users data extracted.")
            
            explorations_df = freeze_columns(explorations_df, columns['explorations'])
            my_admin.upload_dataframe_to_s3(explorations_df, 'explorations_scan', 'json.gz', 'explorations_scan')
        else:
            logger.info("No exploration data extracted.")
        
        if 'DASHBOARDS' in workspaces_df.columns and workspaces_df['DASHBOARDS'].any():
            dashboards_df = workspaces_df[['ID', 'DASHBOARDS']].explode('DASHBOARDS', ignore_index=True)
            dashboards_df = pd.concat([dashboards_df['ID'], pd.json_normalize(dashboards_df['DASHBOARDS'])], axis=1)
            dashboards_df = dashboards_df.rename(columns={'ID':'WORKSPACEID'})
            dashboards_df = generate_dataframe(dashboards_df)
            dashboards_df.dropna(subset=[c for c in dashboards_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['DASHBOARDS'], inplace=True)
            
            if 'TILES' in dashboards_df.columns:
                dashboard_tiles_df = dashboards_df[['ID', 'TILES']].explode('TILES', ignore_index=True)
                dashboard_tiles_df = pd.concat([dashboard_tiles_df['ID'], pd.json_normalize(dashboard_tiles_df['TILES'])], axis=1)
                dashboard_tiles_df = dashboard_tiles_df.rename(columns={'ID':'DASHBOARDID'})
                dashboard_tiles_df = generate_dataframe(dashboard_tiles_df)
                dashboard_tiles_df.dropna(subset=[c for c in dashboard_tiles_df.columns if c!='DASHBOARDID' and c!='EXTRACTEDON'], how='all', inplace=True)
                dashboards_df.drop(columns=['TILES'], inplace=True)
                
                dashboard_tiles_df = freeze_columns(dashboard_tiles_df, columns['dashboardtiles'])
                my_admin.upload_dataframe_to_s3(dashboard_tiles_df, 'dashboardtiles_scan', 'json.gz', 'dashboardtiles_scan')
            else:
                logger.info("No dashboard tile data extracted.")
            
            if 'USERS' in dashboards_df.columns and dashboards_df['USERS'].any():
                dashboard_users_df = dashboards_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                dashboard_users_df = pd.concat([dashboard_users_df['ID'], pd.json_normalize(dashboard_users_df['USERS'])], axis=1)
                dashboard_users_df = dashboard_users_df.rename(columns={'ID':'DASHBOARDID', 'dashboardUserAccessRight':'ACCESSRIGHT'})
                dashboard_users_df = generate_dataframe(dashboard_users_df)
                dashboard_users_df.dropna(subset=[c for c in dashboard_users_df.columns if c!='DASHBOARDID' and c!='EXTRACTEDON'], how='all', inplace=True)
                dashboards_df.drop(columns=['USERS'], inplace=True)
                
                dashboard_users_df = freeze_columns(dashboard_users_df, columns['dashboardusers'])
                my_admin.upload_dataframe_to_s3(dashboard_users_df, 'dashboardusers_scan', 'json.gz', 'dashboardusers_scan')
            else:
                logger.info("No dashboard users data extracted.")
            
            dashboards_df = freeze_columns(dashboards_df, columns['dashboards'])
            my_admin.upload_dataframe_to_s3(dashboards_df, 'dashboards_scan', 'json.gz', 'dashboards_scan')
        else:
            logger.info("No dashboard data extracted.")
        
        if 'DATAFLOWS' in workspaces_df.columns and workspaces_df['DATAFLOWS'].any():
            dataflows_df = workspaces_df[['ID', 'DATAFLOWS']].explode('DATAFLOWS', ignore_index=True)
            dataflows_df = pd.concat([dataflows_df['ID'], pd.json_normalize(dataflows_df['DATAFLOWS'])], axis=1)
            dataflows_df = dataflows_df.rename(columns={'ID':'WORKSPACEID',
                                                        'objectId':'ID',
                                                        'endorsementDetails.endorsement':'ENDORSEMENT',
                                                        'endorsementDetails.certifiedBy':'CERTIFIEDBY'})
            dataflows_df = generate_dataframe(dataflows_df, datetimes=['ModifiedDateTime'])
            dataflows_df.dropna(subset=[c for c in dataflows_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['DATAFLOWS'], inplace=True)
            
            if 'DATASOURCEUSAGES' in dataflows_df.columns:
                dataflow_datasources_df = dataflows_df[['ID', 'DATASOURCEUSAGES']].explode('DATASOURCEUSAGES', ignore_index=True)
                dataflow_datasources_df = pd.concat([dataflow_datasources_df['ID'], pd.json_normalize(dataflow_datasources_df['DATASOURCEUSAGES'])], axis=1)
                dataflow_datasources_df = dataflow_datasources_df.rename(columns={'ID':'DATAFLOWID', 'datasourceInstanceId':'DATASOURCEID'})
                dataflow_datasources_df = generate_dataframe(dataflow_datasources_df)
                dataflow_datasources_df.dropna(subset=[c for c in dataflow_datasources_df.columns if c!='DATAFLOWID' and c!='EXTRACTEDON'], how='all', inplace=True)
                dataflows_df.drop(columns=['DATASOURCEUSAGES'], inplace=True)
                
                dataflow_datasources_df = freeze_columns(dataflow_datasources_df, columns['dataflowdatasources'])
                my_admin.upload_dataframe_to_s3(dataflow_datasources_df, 'dataflowdatasources_scan', 'json.gz', 'dataflowdatasources_scan')
            else:
                logger.info("No dataflow data source data extracted.")
            
            dataflow_rs = ['REFRESHSCHEDULEDAYS', 'REFRESHSCHEDULETIMES', 'REFRESHSCHEDULEENABLED', 'REFRESHSCHEDULELOCALTIMEZONEID', 'REFRESHSCHEDULENOTIFYOPTION']
            dataflow_rs_df = dataflows_df[['ID']+dataflow_rs+['EXTRACTEDON']]
            dataflow_rs_df = dataflow_rs_df.rename(columns={'ID':'DATAFLOWID', **{x:x[15:] for x in dataflow_rs_df.columns if x.startswith('REFRESHSCHEDULE')}})
            dataflow_rs_df = dataflow_rs_df.explode('DAYS', ignore_index=True)
            dataflow_rs_df = dataflow_rs_df.explode('TIMES', ignore_index=True)
            dataflow_rs_df['TIMES'] = dataflow_rs_df['TIMES'].str[:-3]
            dataflow_rs_df[["TIMESUTC", "DAYSUTC", "TIMESUTCDST", "DAYSUTCDST"]] = dataflow_rs_df.apply(lambda row: convert_to_utc(row, offsets), axis=1)
            dataflow_rs_df.fillna(pd.NA, inplace=True)
            dataflow_rs_df.dropna(subset=[c for c in dataflow_rs_df.columns if c!='DATAFLOWID' and c!='EXTRACTEDON'], how='all', inplace=True)
            dataflows_df.drop(columns=dataflow_rs, inplace=True)
            
            if 'RELATIONS' in dataflows_df.columns:
                dataflow_relations_df = dataflows_df[['ID', 'RELATIONS']].explode('RELATIONS', ignore_index=True)
                dataflow_relations_df = pd.concat([dataflow_relations_df['ID'], pd.json_normalize(dataflow_relations_df['RELATIONS'])], axis=1)
                dataflow_relations_df = dataflow_relations_df.rename(columns={'ID':'DATAFLOWID'})
                dataflow_relations_df = generate_dataframe(dataflow_relations_df)
                dataflow_relations_df.dropna(subset=[c for c in dataflow_relations_df.columns if c!='DATAFLOWID' and c!='EXTRACTEDON'], how='all', inplace=True)
                dataflows_df.drop(columns=['RELATIONS'], inplace=True)
                
                dataflow_relations_df = freeze_columns(dataflow_relations_df, columns['dataflowrelations'])
                my_admin.upload_dataframe_to_s3(dataflow_relations_df, 'dataflowrelations_scan', 'json.gz', 'dataflowrelations_scan')
            else:
                logger.info("No dataflow relations data extracted.")
            
            if 'UPSTREAMDATAFLOWS' in dataflows_df.columns:
                dataflow_upsdf_df = dataflows_df[['ID', 'UPSTREAMDATAFLOWS']].explode('UPSTREAMDATAFLOWS', ignore_index=True)
                dataflow_upsdf_df = pd.concat([dataflow_upsdf_df['ID'], pd.json_normalize(dataflow_upsdf_df['UPSTREAMDATAFLOWS'])], axis=1)
                dataflow_upsdf_df = dataflow_upsdf_df.rename(columns={'ID':'DATAFLOWID'})
                dataflow_upsdf_df = generate_dataframe(dataflow_upsdf_df)
                dataflow_upsdf_df.dropna(subset=[c for c in dataflow_upsdf_df.columns if c!='DATAFLOWID' and c!='EXTRACTEDON'], how='all', inplace=True)
                dataflows_df.drop(columns=['UPSTREAMDATAFLOWS'], inplace=True)
                
                dataflow_upsdf_df = freeze_columns(dataflow_upsdf_df, columns['dataflowupstreamdataflows'])
                my_admin.upload_dataframe_to_s3(dataflow_upsdf_df, 'dataflowupstreamdataflows_scan', 'json.gz', 'dataflowupstreamdataflows_scan')
            else:
                logger.info("No dataflow upstream dataflows data extracted.")
            
            if 'UPSTREAMDATAMARTS' in dataflows_df.columns:
                dataflow_upsdm_df = dataflows_df[['ID', 'UPSTREAMDATAMARTS']].explode('UPSTREAMDATAMARTS', ignore_index=True)
                dataflow_upsdm_df = pd.concat([dataflow_upsdm_df['ID'], pd.json_normalize(dataflow_upsdm_df['UPSTREAMDATAMARTS'])], axis=1)
                dataflow_upsdm_df = dataflow_upsdm_df.rename(columns={'ID':'DATAFLOWID'})
                dataflow_upsdm_df = generate_dataframe(dataflow_upsdm_df)
                dataflow_upsdm_df.dropna(subset=[c for c in dataflow_upsdm_df.columns if c!='DATAFLOWID' and c!='EXTRACTEDON'], how='all', inplace=True)
                dataflows_df.drop(columns=['UPSTREAMDATAMARTS'], inplace=True)
                
                dataflow_upsdm_df = freeze_columns(dataflow_upsdm_df, columns['dataflowupstreamdatamarts'])
                my_admin.upload_dataframe_to_s3(dataflow_upsdm_df, 'dataflowupstreamdatamarts_scan', 'json.gz', 'dataflowupstreamdatamarts_scan')
            else:
                logger.info("No dataflow upstream datamarts data extracted.")
            
            if 'USERS' in dataflows_df.columns and dataflows_df['USERS'].any():
                dataflow_users_df = dataflows_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                dataflow_users_df = pd.concat([dataflow_users_df['ID'], pd.json_normalize(dataflow_users_df['USERS'])], axis=1)
                dataflow_users_df = dataflow_users_df.rename(columns={'ID':'DATAFLOWID', 'dataflowUserAccessRight':'ACCESSRIGHT'})
                dataflow_users_df = generate_dataframe(dataflow_users_df)
                dataflow_users_df.dropna(subset=[c for c in dataflow_users_df.columns if c!='DATAFLOWID' and c!='EXTRACTEDON'], how='all', inplace=True)
                dataflows_df.drop(columns=['USERS'], inplace=True)
                
                dataflow_users_df = freeze_columns(dataflow_users_df, columns['dataflowusers'])
                my_admin.upload_dataframe_to_s3(dataflow_users_df, 'dataflowusers_scan', 'json.gz', 'dataflowusers_scan')
            else:
                logger.info("No dataflow users data extracted.")
            
            dataflows_df = freeze_columns(dataflows_df, columns['dataflows'])
            my_admin.upload_dataframe_to_s3(dataflows_df, 'dataflows_scan', 'json.gz', 'dataflows_scan')
            dataflow_rs_df = freeze_columns(dataflow_rs_df, columns['dataflowrefreshschedules'])
            my_admin.upload_dataframe_to_s3(dataflow_rs_df, 'dataflowrefreshschedules_scan', 'json.gz', 'dataflowrefreshschedules_scan')
        else:
            logger.info("No dataflow data extracted.")
        
        if 'DATAMARTS' in workspaces_df.columns and workspaces_df['DATAMARTS'].any():
            datamarts_df = workspaces_df[['ID', 'DATAMARTS']].explode('DATAMARTS', ignore_index=True)
            datamarts_df = pd.concat([datamarts_df['ID'], pd.json_normalize(datamarts_df['DATAMARTS'])], axis=1)
            datamarts_df = datamarts_df.rename(columns={'ID':'WORKSPACEID'})
            datamarts_df = generate_dataframe(datamarts_df, datetimes=['ModifiedDateTime'])
            datamarts_df.dropna(subset=[c for c in datamarts_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['DATAMARTS'], inplace=True)

            if 'DATASOURCEUSAGES' in datamarts_df.columns:
                datamart_datasources_df = datamarts_df[['ID', 'DATASOURCEUSAGES']].explode('DATASOURCEUSAGES', ignore_index=True)
                datamart_datasources_df = pd.concat([datamart_datasources_df['ID'], pd.json_normalize(datamart_datasources_df['DATASOURCEUSAGES'])], axis=1)
                datamart_datasources_df = datamart_datasources_df.rename(columns={'ID':'DATAMARTID', 'datasourceInstanceId':'DATASOURCEID'})
                datamart_datasources_df = generate_dataframe(datamart_datasources_df)
                datamart_datasources_df.dropna(subset=[c for c in datamart_datasources_df.columns if c!='DATAMARTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datamarts_df.drop(columns=['DATASOURCEUSAGES'], inplace=True)
                
                #datamart_datasources_df = freeze_columns(datamart_datasources_df, columns['datamartdatasources'])
                my_admin.upload_dataframe_to_s3(datamart_datasources_df, 'datamartdatasources_scan', 'json.gz', 'datamartdatasources_scan')
            else:
                logger.info("No datamart data source data extracted.")
            
            if 'UPSTREAMDATAFLOWS' in datamarts_df.columns:
                datamart_upsdf_df = datamarts_df[['ID', 'UPSTREAMDATAFLOWS']].explode('UPSTREAMDATAFLOWS', ignore_index=True)
                datamart_upsdf_df = pd.concat([datamart_upsdf_df['ID'], pd.json_normalize(datamart_upsdf_df['UPSTREAMDATAFLOWS'])], axis=1)
                datamart_upsdf_df = datamart_upsdf_df.rename(columns={'ID':'DATAMARTID'})
                datamart_upsdf_df = generate_dataframe(datamart_upsdf_df)
                datamart_upsdf_df.dropna(subset=[c for c in datamart_upsdf_df.columns if c!='DATAMARTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datamarts_df.drop(columns=['UPSTREAMDATAFLOWS'], inplace=True)
                
                #datamart_upsdf_df = freeze_columns(datamart_upsdf_df, columns['datamartupstreamdataflows'])
                my_admin.upload_dataframe_to_s3(datamart_upsdf_df, 'datamartupstreamdataflows_scan', 'json.gz', 'datamartupstreamdataflows_scan')
            else:
                logger.info("No datamart upstream dataflows data extracted.")

            if 'USERS' in datamarts_df.columns and datamarts_df['USERS'].any():
                datamart_users_df = datamarts_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                datamart_users_df = pd.concat([datamart_users_df['ID'], pd.json_normalize(datamart_users_df['USERS'])], axis=1)
                datamart_users_df = datamart_users_df.rename(columns={'ID':'DATAMARTID', 'datamartUserAccessRight':'ACCESSRIGHT'})
                datamart_users_df = generate_dataframe(datamart_users_df)
                datamart_users_df.dropna(subset=[c for c in datamart_users_df.columns if c!='DATAMARTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datamarts_df.drop(columns=['USERS'], inplace=True)
                
                #datamart_users_df = freeze_columns(datamart_users_df, columns['datamartusers'])
                my_admin.upload_dataframe_to_s3(datamart_users_df, 'datamartusers_scan', 'json.gz', 'datamartusers_scan')
            else:
                logger.info("No datamart users data extracted.")
            
            datamarts_df = freeze_columns(datamarts_df, columns['datamarts'])
            my_admin.upload_dataframe_to_s3(datamarts_df, 'datamarts_scan', 'json.gz', 'datamarts_scan')
        else:
            logger.info("No datamart data extracted.")
            
        if 'DATAPIPELINE' in workspaces_df.columns and workspaces_df['DATAPIPELINE'].any():
            datapipelines_df = workspaces_df[['ID', 'DATAPIPELINE']].explode('DATAPIPELINE', ignore_index=True)
            datapipelines_df = pd.concat([datapipelines_df['ID'], pd.json_normalize(datapipelines_df['DATAPIPELINE'])], axis=1)
            datapipelines_df = datapipelines_df.rename(columns={'ID':'WORKSPACEID',
                                                                'endorsementDetails.endorsement':'ENDORSEMENT',
                                                                'endorsementDetails.certifiedBy':'CERTIFIEDBY'})
            datapipelines_df = generate_dataframe(datapipelines_df)
            datapipelines_df.dropna(subset=[c for c in datapipelines_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['DATAPIPELINE'], inplace=True)
            
            if 'USERS' in datapipelines_df.columns and datapipelines_df['USERS'].any():
                datapipeline_users_df = datapipelines_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                datapipeline_users_df = pd.concat([datapipeline_users_df['ID'], pd.json_normalize(datapipeline_users_df['USERS'])], axis=1)
                datapipeline_users_df = datapipeline_users_df.rename(columns={'ID':'DATAPIPELINEID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                datapipeline_users_df = generate_dataframe(datapipeline_users_df)
                datapipeline_users_df.dropna(subset=[c for c in datapipeline_users_df.columns if c!='DATAPIPELINEID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datapipelines_df.drop(columns=['USERS'], inplace=True)
                
                datapipeline_users_df = freeze_columns(datapipeline_users_df, columns['datapipelineusers'])
                my_admin.upload_dataframe_to_s3(datapipeline_users_df, 'datapipelineusers_scan', 'json.gz', 'datapipelineusers_scan')
            else:
                logger.info("No data pipeline users data extracted.")
            
            datapipelines_df = freeze_columns(datapipelines_df, columns['datapipelines'])
            my_admin.upload_dataframe_to_s3(datapipelines_df, 'datapipelines_scan', 'json.gz', 'datapipelines_scan')
        else:
            logger.info("No datapipeline data extracted.")
        
        if 'DATASETS' in workspaces_df.columns and workspaces_df['DATASETS'].any():
            datasets_df = workspaces_df[['ID', 'DATASETS']].explode('DATASETS', ignore_index=True)
            datasets_df = pd.concat([datasets_df['ID'], pd.json_normalize(datasets_df['DATASETS'])], axis=1)
            datasets_df = datasets_df.rename(columns={'ID':'WORKSPACEID',
                                                      'createdDate':'CREATEDDATETIME',
                                                      'endorsementDetails.endorsement':'ENDORSEMENT',
                                                      'endorsementDetails.certifiedBy':'CERTIFIEDBY'})
            datasets_df = generate_dataframe(datasets_df)
            datasets_df.dropna(subset=[c for c in datasets_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['DATASETS'], inplace=True)
            
            if 'DATASOURCEUSAGES' in datasets_df.columns:
                dataset_datasources_df = datasets_df[['ID', 'DATASOURCEUSAGES']].explode('DATASOURCEUSAGES', ignore_index=True)
                dataset_datasources_df = pd.concat([dataset_datasources_df['ID'], pd.json_normalize(dataset_datasources_df['DATASOURCEUSAGES'])], axis=1)
                dataset_datasources_df = dataset_datasources_df.rename(columns={'ID':'DATASETID', 'datasourceInstanceId':'DATASOURCEID'})
                dataset_datasources_df = generate_dataframe(dataset_datasources_df)
                dataset_datasources_df.dropna(subset=[c for c in dataset_datasources_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['DATASOURCEUSAGES'], inplace=True)
                
                dataset_datasources_df = freeze_columns(dataset_datasources_df, columns['datasetdatasources'])
                my_admin.upload_dataframe_to_s3(dataset_datasources_df, 'datasetdatasources_scan', 'json.gz', 'datasetdatasources_scan')
            else:
                logger.info("No dataset data source data extracted.")            
                
            dataset_dqrs = [c for c in datasets_df.columns if c.startswith('DIRECTQUERY')]
            dataset_dqrs_df = datasets_df[['ID']+dataset_dqrs+['EXTRACTEDON']]
            dataset_dqrs_df = dataset_dqrs_df.rename(columns={'ID':'DATASETID', **{x:x[26:] for x in dataset_dqrs_df.columns if x.startswith('DIRECTQUERYREFRESHSCHEDULE')}})
            dataset_dqrs_df = dataset_dqrs_df.explode('DAYS', ignore_index=True)
            dataset_dqrs_df = dataset_dqrs_df.explode('TIMES', ignore_index=True)
            dataset_dqrs_df[["TIMESUTC", "DAYSUTC", "TIMESUTCDST", "DAYSUTCDST"]] = dataset_dqrs_df.apply(lambda row: convert_to_utc(row, offsets), axis=1)
            dataset_dqrs_df.fillna(pd.NA, inplace=True)
            dataset_dqrs_df.dropna(subset=[c for c in dataset_dqrs_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
            datasets_df.drop(columns=dataset_dqrs, inplace=True)
            
            if 'EXPRESSIONS' in datasets_df.columns:
                dataset_expressions_df = datasets_df[['ID', 'EXPRESSIONS']].explode('EXPRESSIONS', ignore_index=True)
                dataset_expressions_df = pd.concat([dataset_expressions_df['ID'], pd.json_normalize(dataset_expressions_df['EXPRESSIONS'])], axis=1)
                dataset_expressions_df = dataset_expressions_df.rename(columns={'ID':'DATASETID'})
                dataset_expressions_df = generate_dataframe(dataset_expressions_df)
                dataset_expressions_df.dropna(subset=[c for c in dataset_expressions_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['EXPRESSIONS'], inplace=True)
                
                #dataset_expressions_df = freeze_columns(dataset_expressions_df, columns['datasetexpressions'])
                my_admin.upload_dataframe_to_s3(dataset_expressions_df, 'datasetexpressions_scan', 'json.gz', 'datasetexpressions_scan')
            else:
                logger.info("No dataset expressions data extracted.")
            
            dataset_rs = ['REFRESHSCHEDULEDAYS', 'REFRESHSCHEDULETIMES', 'REFRESHSCHEDULEENABLED', 'REFRESHSCHEDULELOCALTIMEZONEID', 'REFRESHSCHEDULENOTIFYOPTION']
            dataset_rs_df = datasets_df[['ID']+dataset_rs+['EXTRACTEDON']]
            dataset_rs_df = dataset_rs_df.rename(columns={'ID':'DATASETID', **{x:x[15:] for x in dataset_rs_df.columns if x.startswith('REFRESHSCHEDULE')}})
            dataset_rs_df = dataset_rs_df.explode('DAYS', ignore_index=True)
            dataset_rs_df = dataset_rs_df.explode('TIMES', ignore_index=True)
            dataset_rs_df[["TIMESUTC", "DAYSUTC", "TIMESUTCDST", "DAYSUTCDST"]] = dataset_rs_df.apply(lambda row: convert_to_utc(row, offsets), axis=1)
            dataset_rs_df.fillna(pd.NA, inplace=True)
            dataset_rs_df.dropna(subset=[c for c in dataset_rs_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
            datasets_df.drop(columns=dataset_rs, inplace=True)
            
            if 'RELATIONS' in datasets_df.columns:
                dataset_relations_df = datasets_df[['ID', 'RELATIONS']].explode('RELATIONS', ignore_index=True)
                dataset_relations_df = pd.concat([dataset_relations_df['ID'], pd.json_normalize(dataset_relations_df['RELATIONS'])], axis=1)
                dataset_relations_df = dataset_relations_df.rename(columns={'ID':'DATASETID'})
                dataset_relations_df = generate_dataframe(dataset_relations_df)
                dataset_relations_df.dropna(subset=[c for c in dataset_relations_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['RELATIONS'], inplace=True)
                
                dataset_relations_df = freeze_columns(dataset_relations_df, columns['datasetrelations'])
                my_admin.upload_dataframe_to_s3(dataset_relations_df, 'datasetrelations_scan', 'json.gz', 'datasetrelations_scan')
            else:
                logger.info("No dataset relations data extracted.")
            
            if 'ROLES' in datasets_df.columns:
                dataset_roles_df = datasets_df[['ID', 'ROLES']].explode('ROLES', ignore_index=True)
                dataset_roles_df = pd.concat([dataset_roles_df['ID'], pd.json_normalize(dataset_roles_df['ROLES'])], axis=1)
                dataset_roles_df = dataset_roles_df.rename(columns={'ID':'DATASETID'})
                dataset_roles_df = generate_dataframe(dataset_roles_df)
                dataset_roles_df.dropna(subset=[c for c in dataset_roles_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['ROLES'], inplace=True)
                
                #dataset_roles_df = freeze_columns(dataset_roles_df, columns['datasetroles'])
                my_admin.upload_dataframe_to_s3(dataset_roles_df, 'datasetroles_scan', 'json.gz', 'datasetroles_scan')
            else:
                logger.info("No dataset roles data extracted.")
            
            if 'TABLES' in datasets_df.columns:
                dataset_tables_df = datasets_df[['ID', 'TABLES']].explode('TABLES', ignore_index=True)
                dataset_tables_df = pd.concat([dataset_tables_df['ID'], pd.json_normalize(dataset_tables_df['TABLES'])], axis=1)
                dataset_tables_df = dataset_tables_df.rename(columns={'ID':'DATASETID'})
                dataset_tables_df = generate_dataframe(dataset_tables_df)
                dataset_tables_df.dropna(subset=[c for c in dataset_tables_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['TABLES'], inplace=True)
                
                if 'NAME' in dataset_tables_df.columns and 'COLUMNS' in dataset_tables_df.columns:
                    table_columns_df = dataset_tables_df[['DATASETID', 'NAME', 'COLUMNS']].explode('COLUMNS', ignore_index=True)
                    table_columns_df = pd.concat([table_columns_df[['DATASETID', 'NAME']], pd.json_normalize(table_columns_df['COLUMNS'])], axis=1)
                    table_columns_df = table_columns_df.rename(columns={'NAME':'TABLENAME'})
                    table_columns_df = generate_dataframe(table_columns_df)
                    dataset_tables_df.drop(columns=['COLUMNS'], inplace=True)
                                       
                    #table_columns_df = freeze_columns(table_columns_df, columns['datasetcolumns'])
                    my_admin.upload_dataframe_to_s3(table_columns_df, 'datasetcolumns_scan', 'json.gz', 'datasetcolumns_scan')
                else:
                    logger.info("No dataset table columns data extracted.")
                
                if 'NAME' in dataset_tables_df.columns and 'SOURCE' in dataset_tables_df.columns:
                    table_sources_df = dataset_tables_df[['DATASETID', 'NAME', 'SOURCE']].explode('SOURCE', ignore_index=True)
                    table_sources_df = pd.concat([table_sources_df[['DATASETID', 'NAME']], pd.json_normalize(table_sources_df['SOURCE'])], axis=1)
                    table_sources_df = table_sources_df.rename(columns={'NAME':'TABLENAME'})
                    table_sources_df = generate_dataframe(table_sources_df)
                    dataset_tables_df.drop(columns=['SOURCE'], inplace=True)
                    
                    #table_sources_df = freeze_columns(table_sources_df, columns['datasettableexpressions'])
                    my_admin.upload_dataframe_to_s3(table_sources_df, 'datasettableexpressions_scan', 'json.gz', 'datasettableexpressions_scan')
                else:
                    logger.info("No dataset table sources data extracted.")
                
                if 'NAME' in dataset_tables_df.columns and 'MEASURES' in dataset_tables_df.columns:
                    table_measures_df = dataset_tables_df[['DATASETID', 'NAME', 'MEASURES']].explode('MEASURES', ignore_index=True)
                    table_measures_df = pd.concat([table_measures_df[['DATASETID', 'NAME']], pd.json_normalize(table_measures_df['MEASURES'])], axis=1)
                    table_measures_df = table_measures_df.rename(columns={'NAME':'TABLENAME'})
                    table_measures_df = generate_dataframe(table_measures_df)
                    dataset_tables_df.drop(columns=['MEASURES'], inplace=True)
                    
                    #table_measures_df = freeze_columns(table_measures_df, columns['datasetmeasures'])
                    my_admin.upload_dataframe_to_s3(table_measures_df, 'datasetmeasures_scan', 'json.gz', 'datasetmeasures_scan')
                else:
                    logger.info("No dataset table measures data extracted.")
                
                #dataset_tables_df = freeze_columns(dataset_tables_df, columns['datasettables'])
                my_admin.upload_dataframe_to_s3(dataset_tables_df, 'datasettables_scan', 'json.gz', 'datasettables_scan')
            else:
                logger.info("No dataset tables data extracted.")
            
            if 'UPSTREAMDATAFLOWS' in datasets_df.columns:
                dataset_upsdf_df = datasets_df[['ID', 'UPSTREAMDATAFLOWS']].explode('UPSTREAMDATAFLOWS', ignore_index=True)
                dataset_upsdf_df = pd.concat([dataset_upsdf_df['ID'], pd.json_normalize(dataset_upsdf_df['UPSTREAMDATAFLOWS'])], axis=1)
                dataset_upsdf_df = dataset_upsdf_df.rename(columns={'ID':'DATASETID'})
                dataset_upsdf_df = generate_dataframe(dataset_upsdf_df)
                dataset_upsdf_df.dropna(subset=[c for c in dataset_upsdf_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['UPSTREAMDATAFLOWS'], inplace=True)
                
                dataset_upsdf_df = freeze_columns(dataset_upsdf_df, columns['datasetupstreamdataflows'])
                my_admin.upload_dataframe_to_s3(dataset_upsdf_df, 'datasetupstreamdataflows_scan', 'json.gz', 'datasetupstreamdataflows_scan')
            else:
                logger.info("No dataset upstream dataflows data extracted.")
            
            if 'UPSTREAMDATAMARTS' in datasets_df.columns:
                dataset_upsdm_df = datasets_df[['ID', 'UPSTREAMDATAMARTS']].explode('UPSTREAMDATAMARTS', ignore_index=True)
                dataset_upsdm_df = pd.concat([dataset_upsdm_df['ID'], pd.json_normalize(dataset_upsdm_df['UPSTREAMDATAMARTS'])], axis=1)
                dataset_upsdm_df = dataset_upsdm_df.rename(columns={'ID':'DATASETID'})
                dataset_upsdm_df = generate_dataframe(dataset_upsdm_df)
                dataset_upsdm_df.dropna(subset=[c for c in dataset_upsdm_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['UPSTREAMDATAMARTS'], inplace=True)
                
                dataset_upsdm_df = freeze_columns(dataset_upsdm_df, columns['datasetupstreamdatamarts'])
                my_admin.upload_dataframe_to_s3(dataset_upsdm_df, 'datasetupstreamdatamarts_scan', 'json.gz', 'datasetupstreamdatamarts_scan')
            else:
                logger.info("No dataset upstream datamarts data extracted.")
            
            if 'UPSTREAMDATASETS' in datasets_df.columns:
                dataset_upsds_df = datasets_df[['ID', 'UPSTREAMDATASETS']].explode('UPSTREAMDATASETS', ignore_index=True)
                dataset_upsds_df = pd.concat([dataset_upsds_df['ID'], pd.json_normalize(dataset_upsds_df['UPSTREAMDATASETS'])], axis=1)
                dataset_upsds_df = dataset_upsds_df.rename(columns={'ID':'DATASETID'})
                dataset_upsds_df = generate_dataframe(dataset_upsds_df)
                dataset_upsds_df.dropna(subset=[c for c in dataset_upsds_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['UPSTREAMDATASETS'], inplace=True)
                
                dataset_upsds_df = freeze_columns(dataset_upsds_df, columns['datasetupstreamdatasets'])
                my_admin.upload_dataframe_to_s3(dataset_upsds_df, 'datasetupstreamdatasets_scan', 'json.gz', 'datasetupstreamdatasets_scan')
            else:
                logger.info("No dataset upstream datasets data extracted.")
            
            if 'USERS' in datasets_df.columns and datasets_df['USERS'].any():
                dataset_users_df = datasets_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                dataset_users_df = pd.concat([dataset_users_df['ID'], pd.json_normalize(dataset_users_df['USERS'])], axis=1)
                dataset_users_df = dataset_users_df.rename(columns={'ID':'DATASETID', 'datasetUserAccessRight':'ACCESSRIGHT'})
                dataset_users_df = generate_dataframe(dataset_users_df)
                dataset_users_df.dropna(subset=[c for c in dataset_users_df.columns if c!='DATASETID' and c!='EXTRACTEDON'], how='all', inplace=True)
                datasets_df.drop(columns=['USERS'], inplace=True)
                
                dataset_users_df = freeze_columns(dataset_users_df, columns['datasetusers'])
                my_admin.upload_dataframe_to_s3(dataset_users_df, 'datasetusers_scan', 'json.gz', 'datasetusers_scan')
            else:
                logger.info("No dataset users data extracted.")
            
            datasets_df = freeze_columns(datasets_df, columns['datasets'])
            my_admin.upload_dataframe_to_s3(datasets_df, 'datasets_scan', 'json.gz', 'datasets_scan')
            dataset_dqrs_df = freeze_columns(dataset_dqrs_df, columns['datasetdqrefreshschedules'])
            my_admin.upload_dataframe_to_s3(dataset_dqrs_df, 'datasetdqrefreshschedules_scan', 'json.gz', 'datasetdqrefreshschedules_scan')
            dataset_rs_df = freeze_columns(dataset_rs_df, columns['datasetrefreshschedules'])
            my_admin.upload_dataframe_to_s3(dataset_rs_df, 'datasetrefreshschedules_scan', 'json.gz', 'datasetrefreshschedules_scan')
        else:
            logger.info("No dataset data extracted.")
        
        if 'KQLDATABASE' in workspaces_df.columns and workspaces_df['KQLDATABASE'].any():
            kqldatabases_df = workspaces_df[['ID', 'KQLDATABASE']].explode('KQLDATABASE', ignore_index=True)
            kqldatabases_df = pd.concat([kqldatabases_df['ID'], pd.json_normalize(kqldatabases_df['KQLDATABASE'])], axis=1)
            kqldatabases_df = kqldatabases_df.rename(columns={'ID':'WORKSPACEID',
                                                              'lastUpdatedDate':'LASTUPDATEDDATETIME', 'createdDate':'CREATEDDATETIME',
                                                              **{x:x[19:] for x in kqldatabases_df.columns if x.startswith('extendedProperties.')}})
            kqldatabases_df = generate_dataframe(kqldatabases_df, datetimes=['LASTUPDATEDDATETIME', 'CREATEDDATETIME'])
            kqldatabases_df.dropna(subset=[c for c in kqldatabases_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['KQLDATABASE'], inplace=True)
            
            if 'USERS' in kqldatabases_df.columns and kqldatabases_df['USERS'].any():
                kqldatabase_users_df = kqldatabases_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                kqldatabase_users_df = pd.concat([kqldatabase_users_df['ID'], pd.json_normalize(kqldatabase_users_df['USERS'])], axis=1)
                kqldatabase_users_df = kqldatabase_users_df.rename(columns={'ID':'KQLDATABASEID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                kqldatabase_users_df = generate_dataframe(kqldatabase_users_df)
                kqldatabase_users_df.dropna(subset=[c for c in kqldatabase_users_df.columns if c!='KQLDATABASEID' and c!='EXTRACTEDON'], how='all', inplace=True)
                kqldatabases_df.drop(columns=['USERS'], inplace=True)
                
                kqldatabase_users_df = freeze_columns(kqldatabase_users_df, columns['kqldatabaseusers'])
                my_admin.upload_dataframe_to_s3(kqldatabase_users_df, 'kqldatabaseusers_scan', 'json.gz', 'kqldatabaseusers_scan')
            else:
                logger.info("No kqldatabase users data extracted.")
            
            kqldatabases_df = freeze_columns(kqldatabases_df, columns['kqldatabases'])
            my_admin.upload_dataframe_to_s3(kqldatabases_df, 'kqldatabases_scan', 'json.gz', 'kqldatabases_scan')
        else:
            logger.info("No kqldatabase data extracted.")
        
        if 'LAKEHOUSE' in workspaces_df.columns and workspaces_df['LAKEHOUSE'].any():
            lakehouses_df = workspaces_df[['ID', 'LAKEHOUSE']].explode('LAKEHOUSE', ignore_index=True)
            lakehouses_df = pd.concat([lakehouses_df['ID'], pd.json_normalize(lakehouses_df['LAKEHOUSE'])], axis=1)
            lakehouses_df = lakehouses_df.rename(columns={'ID':'WORKSPACEID',
                                                          'lastUpdatedDate':'LASTUPDATEDDATETIME', 'createdDate':'CREATEDDATETIME',
                                                          **{x:x[19:] for x in lakehouses_df.columns if x.startswith('extendedProperties.')}})
            lakehouses_df = generate_dataframe(lakehouses_df)
            lakehouses_df.dropna(subset=[c for c in lakehouses_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['LAKEHOUSE'], inplace=True)
            
            if 'USERS' in lakehouses_df.columns and lakehouses_df['USERS'].any():
                lakehouse_users_df = lakehouses_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                lakehouse_users_df = pd.concat([lakehouse_users_df['ID'], pd.json_normalize(lakehouse_users_df['USERS'])], axis=1)
                lakehouse_users_df = lakehouse_users_df.rename(columns={'ID':'LAKEHOUSEID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                lakehouse_users_df = generate_dataframe(lakehouse_users_df)
                lakehouse_users_df.dropna(subset=[c for c in lakehouse_users_df.columns if c!='LAKEHOUSEID' and c!='EXTRACTEDON'], how='all', inplace=True)
                lakehouses_df.drop(columns=['USERS'], inplace=True)
                
                lakehouse_users_df = freeze_columns(lakehouse_users_df, columns['lakehouseusers'])
                my_admin.upload_dataframe_to_s3(lakehouse_users_df, 'lakehouseusers_scan', 'json.gz', 'lakehouseusers_scan')
            else:
                logger.info("No lakehouse users data extracted.")
            
            lakehouses_df = freeze_columns(lakehouses_df, columns['lakehouses'])
            my_admin.upload_dataframe_to_s3(lakehouses_df, 'lakehouses_scan', 'json.gz', 'lakehouses_scan')
        else:
            logger.info("No lakehouse data extracted.")
        
        if 'MLEXPERIMENT' in workspaces_df.columns and workspaces_df['MLEXPERIMENT'].any():
            mlexperiments_df = workspaces_df[['ID', 'MLEXPERIMENT']].explode('MLEXPERIMENT', ignore_index=True)
            mlexperiments_df = pd.concat([mlexperiments_df['ID'], pd.json_normalize(mlexperiments_df['MLEXPERIMENT'])], axis=1)
            mlexperiments_df = mlexperiments_df.rename(columns={'ID':'WORKSPACEID',
                                                                'extendedProperties.AmlExperimentId':'MLEXPERIMENTID',
                                                                'extendedProperties.MLFlowExperimentId':'MLFLOWEXPERIMENTID'})
            mlexperiments_df = generate_dataframe(mlexperiments_df)
            mlexperiments_df.dropna(subset=[c for c in mlexperiments_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['MLEXPERIMENT'], inplace=True)
            
            if 'USERS' in mlexperiments_df.columns and mlexperiments_df['USERS'].any():
                mlexperiment_users_df = mlexperiments_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                mlexperiment_users_df = pd.concat([mlexperiment_users_df['ID'], pd.json_normalize(mlexperiment_users_df['USERS'])], axis=1)
                mlexperiment_users_df = mlexperiment_users_df.rename(columns={'ID':'MLEXPERIMENTID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                mlexperiment_users_df = generate_dataframe(mlexperiment_users_df)
                mlexperiment_users_df.dropna(subset=[c for c in mlexperiment_users_df.columns if c!='MLEXPERIMENTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                mlexperiments_df.drop(columns=['USERS'], inplace=True)
                
                #mlexperiment_users_df = freeze_columns(mlexperiment_users_df, columns['mlexperimentusers'])
                my_admin.upload_dataframe_to_s3(mlexperiment_users_df, 'mlexperimentusers_scan', 'json.gz', 'mlexperimentusers_scan')
            else:
                logger.info("No mlexperiment users data extracted.")
            
            mlexperiments_df = freeze_columns(mlexperiments_df, columns['mlexperiments'])
            my_admin.upload_dataframe_to_s3(mlexperiments_df, 'mlexperiments_scan', 'json.gz', 'mlexperiments_scan')
        else:
            logger.info("No mlexperiment data extracted.")
            
        if 'MLMODEL' in workspaces_df.columns and workspaces_df['MLMODEL'].any():
            mlmodels_df = workspaces_df[['ID', 'MLMODEL']].explode('MLMODEL', ignore_index=True)
            mlmodels_df = pd.concat([mlmodels_df['ID'], pd.json_normalize(mlmodels_df['MLMODEL'])], axis=1)
            mlmodels_df = mlmodels_df.rename(columns={'ID':'WORKSPACEID'})
            mlmodels_df = generate_dataframe(mlmodels_df)
            mlmodels_df.dropna(subset=[c for c in mlmodels_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['MLMODEL'], inplace=True)
            
            if 'USERS' in mlmodels_df.columns and mlmodels_df['USERS'].any():
                mlmodel_users_df = mlmodels_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                mlmodel_users_df = pd.concat([mlmodel_users_df['ID'], pd.json_normalize(mlmodel_users_df['USERS'])], axis=1)
                mlmodel_users_df = mlmodel_users_df.rename(columns={'ID':'MLMODELID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                mlmodel_users_df = generate_dataframe(mlmodel_users_df)
                mlmodel_users_df.dropna(subset=[c for c in mlmodel_users_df.columns if c!='MLMODELID' and c!='EXTRACTEDON'], how='all', inplace=True)
                mlmodels_df.drop(columns=['USERS'], inplace=True)
                
                #mlmodel_users_df = freeze_columns(mlmodel_users_df, columns['mlmodelusers'])
                my_admin.upload_dataframe_to_s3(mlmodel_users_df, 'mlmodelusers_scan', 'json.gz', 'mlmodelusers_scan')
            else:
                logger.info("No mlmodel users data extracted.")
            
            mlmodels_df = freeze_columns(mlmodels_df, columns['mlmodels'])
            my_admin.upload_dataframe_to_s3(mlmodels_df, 'mlmodels_scan', 'json.gz', 'mlmodels_scan')
        else:
            logger.info("No mlmodel data extracted.")
        
        if 'NOTEBOOK' in workspaces_df.columns and workspaces_df['NOTEBOOK'].any():
            notebooks_df = workspaces_df[['ID', 'NOTEBOOK']].explode('NOTEBOOK', ignore_index=True)
            notebooks_df = pd.concat([notebooks_df['ID'], pd.json_normalize(notebooks_df['NOTEBOOK'])], axis=1)
            notebooks_df = notebooks_df.rename(columns={'ID':'WORKSPACEID'})
            notebooks_df = generate_dataframe(notebooks_df)
            notebooks_df.dropna(subset=[c for c in notebooks_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['NOTEBOOK'], inplace=True)
            
            if 'USERS' in notebooks_df.columns and notebooks_df['USERS'].any():
                notebook_users_df = notebooks_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                notebook_users_df = pd.concat([notebook_users_df['ID'], pd.json_normalize(notebook_users_df['USERS'])], axis=1)
                notebook_users_df = notebook_users_df.rename(columns={'ID':'NOTEBOOKID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                notebook_users_df = generate_dataframe(notebook_users_df)
                notebook_users_df.dropna(subset=[c for c in notebook_users_df.columns if c!='NOTEBOOKID' and c!='EXTRACTEDON'], how='all', inplace=True)
                notebooks_df.drop(columns=['USERS'], inplace=True)
                
                notebook_users_df = freeze_columns(notebook_users_df, columns['notebookusers'])
                my_admin.upload_dataframe_to_s3(notebook_users_df, 'notebookusers_scan', 'json.gz', 'notebookusers_scan')
            else:
                logger.info("No notebook users data extracted.")
            
            notebooks_df = freeze_columns(notebooks_df, columns['notebooks'])
            my_admin.upload_dataframe_to_s3(notebooks_df, 'notebooks_scan', 'json.gz', 'notebooks_scan')
        else:
            logger.info("No notebook data extracted.")
        
        if 'ORGAPP' in workspaces_df.columns and workspaces_df['ORGAPP'].any():
            orgapps_df = workspaces_df[['ID', 'ORGAPP']].explode('ORGAPP', ignore_index=True)
            orgapps_df = pd.concat([orgapps_df['ID'], pd.json_normalize(orgapps_df['ORGAPP'])], axis=1)
            orgapps_df = orgapps_df.rename(columns={'ID':'WORKSPACEID'})
            orgapps_df = generate_dataframe(orgapps_df)
            orgapps_df.dropna(subset=[c for c in orgapps_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['ORGAPP'], inplace=True)
            
            if 'USERS' in orgapps_df.columns and orgapps_df['USERS'].any():
                orgapp_users_df = orgapps_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                orgapp_users_df = pd.concat([orgapp_users_df['ID'], pd.json_normalize(orgapp_users_df['USERS'])], axis=1)
                orgapp_users_df = orgapp_users_df.rename(columns={'ID':'ORGAPPID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                orgapp_users_df = generate_dataframe(orgapp_users_df)
                orgapp_users_df.dropna(subset=[c for c in orgapp_users_df.columns if c!='ORGAPPID' and c!='EXTRACTEDON'], how='all', inplace=True)
                orgapps_df.drop(columns=['USERS'], inplace=True)
                
                #orgapp_users_df = freeze_columns(orgapp_users_df, columns['orgappusers'])
                my_admin.upload_dataframe_to_s3(orgapp_users_df, 'orgappusers_scan', 'json.gz', 'orgappusers_scan')
            else:
                logger.info("No orgapp users data extracted.")
            
            #orgapps_df = freeze_columns(orgapps_df, columns['orgapps'])
            my_admin.upload_dataframe_to_s3(orgapps_df, 'orgapps_scan', 'json.gz', 'orgapps_scan')
        else:
            logger.info("No orgapp data extracted.")
            
        if 'REFLEX' in workspaces_df.columns and workspaces_df['REFLEX'].any():
            reflexes_df = workspaces_df[['ID', 'REFLEX']].explode('REFLEX', ignore_index=True)
            reflexes_df = pd.concat([reflexes_df['ID'], pd.json_normalize(reflexes_df['REFLEX'])], axis=1)
            reflexes_df = reflexes_df.rename(columns={'ID':'WORKSPACEID',
                                                      'extendedProperties.Aria.DocumentId':'ARIADOCUMENTID',
                                                      'extendedProperties.Version':'VERSION'})
            reflexes_df = generate_dataframe(reflexes_df)
            reflexes_df.dropna(subset=[c for c in reflexes_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['REFLEX'], inplace=True)
            
            if 'USERS' in reflexes_df.columns and reflexes_df['USERS'].any():
                reflex_users_df = reflexes_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                reflex_users_df = pd.concat([reflex_users_df['ID'], pd.json_normalize(reflex_users_df['USERS'])], axis=1)
                reflex_users_df = reflex_users_df.rename(columns={'ID':'REFLEXID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                reflex_users_df = generate_dataframe(reflex_users_df)
                reflex_users_df.dropna(subset=[c for c in reflex_users_df.columns if c!='REFLEXID' and c!='EXTRACTEDON'], how='all', inplace=True)
                reflexes_df.drop(columns=['USERS'], inplace=True)
                
                reflex_users_df = freeze_columns(reflex_users_df, columns['reflexusers'])
                my_admin.upload_dataframe_to_s3(reflex_users_df, 'reflexusers_scan', 'json.gz', 'reflexusers_scan')
            else:
                logger.info("No reflex users data extracted.")
            
            reflexes_df = freeze_columns(reflexes_df, columns['reflexes'])
            my_admin.upload_dataframe_to_s3(reflexes_df, 'reflexes_scan', 'json.gz', 'reflexes_scan')
        else:
            logger.info("No reflex data extracted.")
        
        if 'REPORTS' in workspaces_df.columns and workspaces_df['REPORTS'].any():
            reports_df = workspaces_df[['ID', 'REPORTS']].explode('REPORTS', ignore_index=True)
            reports_df = pd.concat([reports_df['ID'], pd.json_normalize(reports_df['REPORTS'])], axis=1)
            reports_df = reports_df.rename(columns={'ID':'WORKSPACEID',
                                                    'endorsementDetails.endorsement':'ENDORSEMENT',
                                                    'endorsementDetails.certifiedBy':'CERTIFIEDBY',
                                                    'originalReportObjectId':'ORIGINALREPORTID'})
            reports_df = generate_dataframe(reports_df, datetimes=['CreatedDateTime', 'ModifiedDateTime'])
            reports_df.dropna(subset=[c for c in reports_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['REPORTS'], inplace=True)
            
            if 'RELATIONS' in reports_df.columns:
                report_relations_df = reports_df[['ID', 'RELATIONS']].explode('RELATIONS', ignore_index=True)
                report_relations_df = pd.concat([report_relations_df['ID'], pd.json_normalize(report_relations_df['RELATIONS'])], axis=1)
                report_relations_df = report_relations_df.rename(columns={'ID':'REPORTID'})
                report_relations_df = generate_dataframe(report_relations_df)
                report_relations_df.dropna(subset=[c for c in report_relations_df.columns if c!='REPORTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                reports_df.drop(columns=['RELATIONS'], inplace=True)
                
                report_relations_df = freeze_columns(report_relations_df, columns['reportrelations'])
                my_admin.upload_dataframe_to_s3(report_relations_df, 'reportrelations_scan', 'json.gz', 'reportrelations_scan')
            else:
                logger.info("No report relations data extracted.")
            
            if 'USERS' in reports_df.columns and reports_df['USERS'].any():
                report_users_df = reports_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                report_users_df = pd.concat([report_users_df['ID'], pd.json_normalize(report_users_df['USERS'])], axis=1)
                report_users_df = report_users_df.rename(columns={'ID':'REPORTID', 'reportUserAccessRight':'ACCESSRIGHT'})
                report_users_df = generate_dataframe(report_users_df)
                report_users_df.dropna(subset=[c for c in report_users_df.columns if c!='REPORTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                reports_df.drop(columns=['USERS'], inplace=True)
                
                report_users_df = freeze_columns(report_users_df, columns['reportusers'])
                my_admin.upload_dataframe_to_s3(report_users_df, 'reportusers_scan', 'json.gz', 'reportusers_scan')
            else:
                logger.info("No report users data extracted.")
            
            reports_df = freeze_columns(reports_df, columns['reports'])
            my_admin.upload_dataframe_to_s3(reports_df, 'reports_scan', 'json.gz', 'reports_scan')
        else:
            logger.info("No report data extracted.")
        
        if 'SQLANALYTICSENDPOINT' in workspaces_df.columns and workspaces_df['SQLANALYTICSENDPOINT'].any():
            sqlanalyticsendpoints_df = workspaces_df[['ID', 'SQLANALYTICSENDPOINT']].explode('SQLANALYTICSENDPOINT', ignore_index=True)
            sqlanalyticsendpoints_df = pd.concat([sqlanalyticsendpoints_df['ID'], pd.json_normalize(sqlanalyticsendpoints_df['SQLANALYTICSENDPOINT'])], axis=1)
            sqlanalyticsendpoints_df = sqlanalyticsendpoints_df.rename(columns={'ID':'WORKSPACEID'})
            sqlanalyticsendpoints_df = generate_dataframe(sqlanalyticsendpoints_df)
            sqlanalyticsendpoints_df.dropna(subset=[c for c in sqlanalyticsendpoints_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['SQLANALYTICSENDPOINT'], inplace=True)
            
            if 'USERS' in sqlanalyticsendpoints_df.columns and sqlanalyticsendpoints_df['USERS'].any():
                sqlanalyticsendpoint_users_df = sqlanalyticsendpoints_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                sqlanalyticsendpoint_users_df = pd.concat([sqlanalyticsendpoint_users_df['ID'], pd.json_normalize(sqlanalyticsendpoint_users_df['USERS'])], axis=1)
                sqlanalyticsendpoint_users_df = sqlanalyticsendpoint_users_df.rename(columns={'ID':'SQLANALYTICSENDPOINTID', 'datamartUserAccessRight':'ACCESSRIGHT'})
                sqlanalyticsendpoint_users_df = generate_dataframe(sqlanalyticsendpoint_users_df)
                sqlanalyticsendpoint_users_df.dropna(subset=[c for c in sqlanalyticsendpoint_users_df.columns if c!='SQLANALYTICSENDPOINTID' and c!='EXTRACTEDON'], how='all', inplace=True)
                sqlanalyticsendpoints_df.drop(columns=['USERS'], inplace=True)
                
                sqlanalyticsendpoint_users_df = freeze_columns(sqlanalyticsendpoint_users_df, columns['sqlanalyticsendpointusers'])
                my_admin.upload_dataframe_to_s3(sqlanalyticsendpoint_users_df, 'sqlanalyticsendpointusers_scan', 'json.gz', 'sqlanalyticsendpointusers_scan')
            else:
                logger.info("No sqlanalyticsendpoint users data extracted.")
            
            sqlanalyticsendpoints_df = freeze_columns(sqlanalyticsendpoints_df, columns['sqlanalyticsendpoints'])
            my_admin.upload_dataframe_to_s3(sqlanalyticsendpoints_df, 'sqlanalyticsendpoints_scan', 'json.gz', 'sqlanalyticsendpoints_scan')
        else:
            logger.info("No sqlanalyticsendpoint data extracted.")
        
        if 'SQLDATABASE' in workspaces_df.columns and workspaces_df['SQLDATABASE'].any():
            sqldatabases_df = workspaces_df[['ID', 'SQLDATABASE']].explode('SQLDATABASE', ignore_index=True)
            sqldatabases_df = pd.concat([sqldatabases_df['ID'], pd.json_normalize(sqldatabases_df['SQLDATABASE'])], axis=1)
            sqldatabases_df = sqldatabases_df.rename(columns={'ID':'WORKSPACEID', **{x:x[19:] for x in sqldatabases_df.columns if x.startswith('extendedProperties.')}})
            sqldatabases_df = generate_dataframe(sqldatabases_df)
            sqldatabases_df.dropna(subset=[c for c in sqldatabases_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['SQLDATABASE'], inplace=True)
            
            if 'USERS' in sqldatabases_df.columns and sqldatabases_df['USERS'].any():
                sqldatabase_users_df = sqldatabases_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                sqldatabase_users_df = pd.concat([sqldatabase_users_df['ID'], pd.json_normalize(sqldatabase_users_df['USERS'])], axis=1)
                sqldatabase_users_df = sqldatabase_users_df.rename(columns={'ID':'SQLDATABASEID', 'artifactUserAccessRight':'ACCESSRIGHT'})
                sqldatabase_users_df = generate_dataframe(sqldatabase_users_df)
                sqldatabase_users_df.dropna(subset=[c for c in sqldatabase_users_df.columns if c!='SQLDATABASEID' and c!='EXTRACTEDON'], how='all', inplace=True)
                sqldatabases_df.drop(columns=['USERS'], inplace=True)
                
                sqldatabase_users_df = freeze_columns(sqldatabase_users_df, columns['sqldatabaseusers'])
                my_admin.upload_dataframe_to_s3(sqldatabase_users_df, 'sqldatabaseusers_scan', 'json.gz', 'sqldatabaseusers_scan')
            else:
                logger.info("No sqldatabase users data extracted.")
            
            sqldatabases_df = freeze_columns(sqldatabases_df, columns['sqldatabases'])
            my_admin.upload_dataframe_to_s3(sqldatabases_df, 'sqldatabases_scan', 'json.gz', 'sqldatabases_scan')
        else:
            logger.info("No sqldatabase data extracted.")
        
        if 'WAREHOUSES' in workspaces_df.columns and workspaces_df['WAREHOUSES'].any():
            warehouses_df = workspaces_df[['ID', 'WAREHOUSES']].explode('WAREHOUSES', ignore_index=True)
            warehouses_df = pd.concat([warehouses_df['ID'], pd.json_normalize(warehouses_df['WAREHOUSES'])], axis=1)
            warehouses_df = warehouses_df.rename(columns={'ID':'WORKSPACEID'})
            warehouses_df = generate_dataframe(warehouses_df)
            warehouses_df.dropna(subset=[c for c in warehouses_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
            workspaces_df.drop(columns=['WAREHOUSES'], inplace=True)
            
            if 'USERS' in warehouses_df.columns and warehouses_df['USERS'].any():
                warehouse_users_df = warehouses_df[['ID', 'USERS']].explode('USERS', ignore_index=True)
                warehouse_users_df = pd.concat([warehouse_users_df['ID'], pd.json_normalize(warehouse_users_df['USERS'])], axis=1)
                warehouse_users_df = warehouse_users_df.rename(columns={'ID':'WAREHOUSEID', 'datamartUserAccessRight':'ACCESSRIGHT'})
                warehouse_users_df = generate_dataframe(warehouse_users_df)
                warehouse_users_df.dropna(subset=[c for c in warehouse_users_df.columns if c!='WAREHOUSEID' and c!='EXTRACTEDON'], how='all', inplace=True)
                warehouses_df.drop(columns=['USERS'], inplace=True)
                
                warehouse_users_df = freeze_columns(warehouse_users_df, columns['warehouseusers'])
                my_admin.upload_dataframe_to_s3(warehouse_users_df, 'warehouseusers_scan', 'json.gz', 'warehouseusers_scan')
            else:
                logger.info("No warehouse users data extracted.")
            
            warehouses_df = freeze_columns(warehouses_df, columns['warehouses'])
            my_admin.upload_dataframe_to_s3(warehouses_df, 'warehouses_scan', 'json.gz', 'warehouses_scan')
        else:
            logger.info("No warehouse data extracted.")

        workspaces_df = freeze_columns(workspaces_df, columns['workspaces'])
        my_admin.upload_dataframe_to_s3(workspaces_df, 'workspaces_scan', 'json.gz', 'workspaces_scan')
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()