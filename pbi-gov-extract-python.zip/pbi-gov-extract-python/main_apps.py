"""
main_apps.py

Description:
    This script pulls Power BI apps and app users data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_apps.py <configuration file>

Dependencies:
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-12-11      Abhay Agarwal              Initial Version
                Samir Mamedov
--------------------------------------------------------------------------------------------------
"""


import argparse
from datetime import datetime, timedelta
import logging
import os

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('apps.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan apps metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file)
        
        # Get apps and generate a DataFrame
        apps = my_admin.get_apps()
        logger.info("Apps data fetched.")
        apps_df = generate_dataframe(apps, drop=['Users'], datetimes=['LastUpdate'])
        
        # Track time to prevent token expiration
        start_time = datetime.now()
        
        # Get app users and generate a DataFrame
        appusers = []
        for app in apps_df['ID']:
            users = my_admin.get_app_users(app)
            
            for user in users:
                appusers.append({'Id':app, **user})
            
            if datetime.now() - start_time > timedelta(hours=1):
                logger.info("Token expired. Renewing...")
                my_admin = Admin(args.config_file)
        
        logger.info("Users data fetched.")
        users_df = generate_dataframe(appusers).rename(columns={'APPUSERACCESSRIGHT':'ACCESSRIGHT'})

        # Upload DataFrames to AWS S3 bucket
        my_admin.upload_dataframe_to_s3(apps_df, 'apps', 'json.gz', 'apps')
        my_admin.upload_dataframe_to_s3(users_df, 'appusers', 'json.gz', 'appusers')
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()