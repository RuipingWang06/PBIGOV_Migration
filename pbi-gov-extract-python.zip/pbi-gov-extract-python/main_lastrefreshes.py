"""
main_lastrefreshes.py

Description:
    This script pulls the last refresh data for Power BI refreshables and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_lastrefreshes.py <configuration file> --run_frequency <frequency>

Dependencies:
    - pandas: For processing data
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2025-01-29      Abhay Agarwal              Initial Version
                Samir Mamedov
--------------------------------------------------------------------------------------------------
"""


import argparse
from datetime import datetime, timedelta
import json
import logging
import os

import pandas as pd

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('lastrefreshes.log')
logger = logging.getLogger(__name__) # Logger for the current script


def high_level_error(x):
    if not pd.isna(x):
        return json.loads(x)["error"]["code"]


def real_error(x):
    if not pd.isna(x):
        error_details = json.loads(x)["error"]["pbi.error"]["details"][0]["detail"]["value"].split(' Table: ')
        result_str = ""

        if error_details[0][0] == "{":
            error_items = json.loads(error_details[0].replace("\\.", ".").replace("\\{", "{"))["error"]["pbi.error"]["details"]
            for item in error_items:
                result_str += (item['detail']['value'] + ".")
        else:
            result_str = error_details[0] + "."
        
        if len(error_details) > 1:
            result_str += f" Table: {"".join(error_details[1:])}"
        
        return "".join(result_str.splitlines())


def main():
    """
    Main function to scan last refresh metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    parser.add_argument(
        "--run_frequency",
        type=str,
        required=False,
        default="full",
        choices=["hourly", "daily", "full"],
        help="Frequency to run the script - hourly, daily, or full, defaults to hourly",
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
        
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file)
        
        # Get capacities
        capacities = my_admin.get_capacities_from_config(args.config_file)
        
        # Track time to prevent token expiration
        start_time = datetime.now()
        
        # Get refreshables, extract last refreshes, and generate a DataFrame
        refreshables = []
        for c in capacities:
            refreshables.extend(my_admin.get_refreshables_for_capacity(c))
            
            if datetime.now() - start_time > timedelta(hours=1):
                logger.info("Token expired. Renewing...")
                my_admin = Admin(args.config_file)

        logger.info("Refreshables data fetched.")
        refreshables_df = generate_dataframe(refreshables, drop=['StartTime', 'EndTime', 'AverageDuration', 'MedianDuration'],
                                             datetimes=['LastRefreshStartTime', 'LastRefreshEndTime'])
        refreshables_df['CONFIGUREDBY'] = refreshables_df['CONFIGUREDBY'].apply(lambda x: x[0])
        refreshables_df = refreshables_df.loc[:, ~refreshables_df.columns.str.startswith('REFRESH')]
        refreshables_df.rename(columns=lambda x: x[11:] if x.startswith('LASTREFRESH') and x != 'LASTREFRESHID' else x, inplace=True)
        refreshables_df["HIGHLEVELERROR"] = refreshables_df["SERVICEEXCEPTIONJSON"].map(high_level_error)
        refreshables_df["REALERROR"] = refreshables_df["SERVICEEXCEPTIONJSON"].map(real_error)
        refreshables_df.rename(columns={'SERVICEEXCEPTIONJSON': 'FULLERROR'}, inplace=True)
        refreshables_df = refreshables_df[refreshables_df['LASTREFRESHID'].astype(str).ne('') & refreshables_df['LASTREFRESHID'].notna()]
        refreshables_df = refreshables_df[[col for col in refreshables_df.columns if col not in ['FULLERROR', 'EXTRACTEDON']] + ['FULLERROR', 'EXTRACTEDON']]
        refreshables_df.fillna(pd.NA, inplace=True)
        logger.info("Last refreshes data extracted.")
        
        # Filter based on frequency
        if args.run_frequency == "hourly":
            refreshables_df = refreshables_df[pd.to_datetime(refreshables_df['STARTTIME'])>=datetime.now()-timedelta(hours=1)]
        elif args.run_frequency == "daily":
            refreshables_df = refreshables_df[pd.to_datetime(refreshables_df['STARTTIME'])>=datetime.now()-timedelta(hours=24)]
            
        # Upload DataFrame to AWS S3 bucket
        my_admin.upload_dataframe_to_s3(refreshables_df, 'lastrefreshes', 'json.gz', 'lastrefreshes')
        logger.info("DataFrame uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()