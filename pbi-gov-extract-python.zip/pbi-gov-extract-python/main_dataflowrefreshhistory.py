"""
main_dataflowrefreshhistory.py

Description:
    This script pulls Power BI dataflow transactions data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_dataflowrefreshhistory.py <configuration file> -g <group> -d <dataflow>

Dependencies:
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2025-05-08      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


import argparse
import logging
import os

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('dataflowrefreshhistory.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan dataflow transcations data and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    parser.add_argument(
        "-g",
        "--group",
        type=str,
        default="fd44a8b5-b2a7-4fbd-aa19-c6d8e54fc1b1",
        help="Group ID"
    )
    parser.add_argument(
        "-d",
        "--dataflow",
        type=str,
        default="9295bdd1-d8bd-4d3b-a252-d99d2907f9dc",
        help="Dataflow ID"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file, base_url="https://api.powerbi.com/v1.0/myorg/")
        
        # Get transactions and generate a DataFrame
        transactions = my_admin.dataflows_get_dataflow_transactions(group=args.group,
                                                                    dataflow=args.dataflow)
        logger.info("Transactions data fetched.")
        transactions_df = generate_dataframe(transactions, datetimes=['StartTime', 'EndTime'])
        transactions_df['DATAFLOWID'] = args.dataflow

        # Upload DataFrames to AWS S3 bucket
        my_admin.upload_dataframe_to_s3(transactions_df, 'dataflowrefreshhistory', 'json.gz', 'dataflowrefreshhistory')
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()