"""
main_deploymentpipelines.py

Description:
    This script pulls Power BI pipelines, pipeline users, and stages data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_deploymentpipelines.py <configuration file>

Dependencies:
    - pandas: For processing data
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-12-19      SiaChing Low               Initial Version
                Samir Mamedov
--------------------------------------------------------------------------------------------------
"""


import argparse
import logging
import os

import pandas as pd

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('deploymentpipelines.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan pipelines metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file)
        
        # Get pipelines and generate a DataFrame
        pipelines = my_admin.get_pipelines(expand=['stages', 'users'])
        logger.info("Pipelines data fetched.")
        pipelines_df = generate_dataframe(pipelines)
        
        # Extract stages and users of the pipelines
        pipeline_stages = pipelines_df[['ID','STAGES']].explode('STAGES', ignore_index=True)
        pipeline_stages = pd.concat([pipeline_stages['ID'], pd.json_normalize(pipeline_stages['STAGES'])], axis=1)
        pipeline_stages = generate_dataframe(pipeline_stages)
        pipeline_users = pipelines_df[['ID','USERS']].explode('USERS', ignore_index=True)
        pipeline_users = pd.concat([pipeline_users['ID'], pd.json_normalize(pipeline_users['USERS'])], axis=1)
        pipeline_users = generate_dataframe(pipeline_users)
        pipeline_users.dropna(subset=['ACCESSRIGHT', 'IDENTIFIER', 'PRINCIPALTYPE'], how='all', inplace=True)

        # Upload DataFrames to AWS S3 bucket
        my_admin.upload_dataframe_to_s3(pipelines_df[['ID','DISPLAYNAME','DESCRIPTION']], 'deploymentpipelines', 'json.gz', 'deploymentpipelines')
        my_admin.upload_dataframe_to_s3(pipeline_stages, 'deploymentpipelinestages', 'json.gz', 'deploymentpipelinestages')
        my_admin.upload_dataframe_to_s3(pipeline_users, 'deploymentpipelineusers', 'json.gz', 'deploymentpipelineusers')
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()