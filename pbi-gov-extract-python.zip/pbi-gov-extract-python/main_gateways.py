"""
main_gateways.py

Description:
    This script pulls Power BI gateways data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_gateways.py <configuration file>

Dependencies:
    - pandas: For processing data
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2025-04-17      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


import argparse
import ast
import logging
import os

import pandas as pd

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('gateways.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan gateways metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file, base_url="https://api.powerbi.com/v2.0/myorg/")
        
        # Get gateways and generate a DataFrame
        gateways = my_admin.get_gateways()
        logger.info("Gateways data fetched.")
        gateways_df = generate_dataframe(gateways)
        
        # Extract instances and permissions of the gateways
        gateway_instances = gateways_df[['ID','MEMBERGATEWAYS']].explode('MEMBERGATEWAYS', ignore_index=True)
        gateway_instances = pd.concat([gateway_instances['ID'], pd.json_normalize(gateway_instances['MEMBERGATEWAYS'])], axis=1)
        gateway_instances.rename(columns={'ID':'GATEWAYID'}, inplace=True)
        gateway_instances['annotation'] = gateway_instances['annotation'].str.replace(':null', ':None').apply(lambda x: ast.literal_eval(x) if pd.notna(x) else {})
        gateway_instances = pd.concat([gateway_instances, pd.json_normalize(gateway_instances['annotation'])], axis=1)
        gateway_instances['gatewayContactInformation'] = gateway_instances['gatewayContactInformation'].apply(lambda x: x[0])
        gateway_instances = generate_dataframe(gateway_instances, drop=['Annotation'])
        gateway_instances.dropna(subset=[c for c in gateway_instances.columns if c!='GATEWAYID' and c!='EXTRACTEDON'], how='all', inplace=True)
        gateways_df.drop(columns=['MEMBERGATEWAYS'], inplace=True)
        
        gateway_permissions = gateways_df[['ID','PERMISSIONS']].explode('PERMISSIONS', ignore_index=True)
        gateway_permissions = pd.concat([gateway_permissions['ID'], pd.json_normalize(gateway_permissions['PERMISSIONS'])], axis=1)
        gateway_permissions.rename(columns={'ID':'GATEWAYID'}, inplace=True)
        gateway_permissions = generate_dataframe(gateway_permissions)
        gateway_permissions.dropna(subset=[c for c in gateway_permissions.columns if c!='GATEWAYID' and c!='EXTRACTEDON'], how='all', inplace=True)
        gateways_df.drop(columns=['PERMISSIONS'], inplace=True)

        # Upload DataFrames to AWS S3 bucket

        my_admin.upload_dataframe_to_s3(gateways_df, 'gatewayclusters', 'json.gz', 'gatewayclusters')
        my_admin.upload_dataframe_to_s3(gateway_instances, 'gatewayinstances', 'json.gz', 'gatewayinstances')
        my_admin.upload_dataframe_to_s3(gateway_permissions, 'gatewayclusterpermissions', 'json.gz', 'gatewayclusterpermissions')
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()