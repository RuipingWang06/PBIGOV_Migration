"""
main_groups.py

Description:
    This script pulls Power BI groups data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_groups.py -c <configuration file> -m <mode> -s <since>

Dependencies:
    - pandas: For processing data
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2025-04-30      Samir Mamedov              Initial Version
--------------------------------------------------------------------------------------------------
"""


import argparse
import logging
import os

import pandas as pd

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('groups.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan groups metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file)
        
        # Get groups and generate a DataFrame
        groups = my_admin.get_groups(expand=['users', 'reports', 'dashboards', 'datasets', 'dataflows', 'workbooks'])
        logger.info("Groups data fetched.")
        groups_df = generate_dataframe(groups)
        
        # Extract artifacts and users of the groups
        dashboards_df = groups_df[['ID','DASHBOARDS']].explode('DASHBOARDS', ignore_index=True)
        dashboards_df = pd.concat([dashboards_df['ID'], pd.json_normalize(dashboards_df['DASHBOARDS'])], axis=1)
        dashboards_df.rename(columns={'ID':'WORKSPACEID'}, inplace=True)
        dashboards_df = generate_dataframe(dashboards_df, drop=['Users', 'Subscriptions'])
        dashboards_df.dropna(subset=[c for c in dashboards_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
        groups_df.drop(columns=['DASHBOARDS'], inplace=True)
        
        dataflows_df = groups_df[['ID','DATAFLOWS']].explode('DATAFLOWS', ignore_index=True)
        dataflows_df = pd.concat([dataflows_df['ID'], pd.json_normalize(dataflows_df['DATAFLOWS'])], axis=1)
        dataflows_df.rename(columns={'ID':'WORKSPACEID'}, inplace=True)
        dataflows_df = generate_dataframe(dataflows_df, drop=['Users'])
        dataflows_df.dropna(subset=[c for c in dataflows_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
        groups_df.drop(columns=['DATAFLOWS'], inplace=True)
        
        datasets_df = groups_df[['ID','DATASETS']].explode('DATASETS', ignore_index=True)
        datasets_df = pd.concat([datasets_df['ID'], pd.json_normalize(datasets_df['DATASETS'])], axis=1)
        datasets_df.rename(columns={'ID':'WORKSPACEID'}, inplace=True)
        datasets_df = generate_dataframe(datasets_df, drop=['UpstreamDatasets', 'Users'])
        datasets_df.dropna(subset=[c for c in datasets_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
        groups_df.drop(columns=['DATASETS'], inplace=True)
        
        reports_df = groups_df[['ID','REPORTS']].explode('REPORTS', ignore_index=True)
        reports_df = pd.concat([reports_df['ID'], pd.json_normalize(reports_df['REPORTS'])], axis=1)
        reports_df.rename(columns={'ID':'WORKSPACEID'}, inplace=True)
        reports_df = generate_dataframe(reports_df, drop=['Users', 'Subscriptions'])
        reports_df.dropna(subset=[c for c in reports_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
        groups_df.drop(columns=['REPORTS'], inplace=True)
        
        users_df = groups_df[['ID','USERS']].explode('USERS', ignore_index=True)
        users_df = pd.concat([users_df['ID'], pd.json_normalize(users_df['USERS'])], axis=1)
        users_df.rename(columns={'ID':'WORKSPACEID', 'groupUserAccessRight':'ACCESSRIGHT'}, inplace=True)
        users_df = generate_dataframe(users_df)
        users_df.dropna(subset=[c for c in users_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
        groups_df.drop(columns=['USERS'], inplace=True)
        
        workbooks_df = groups_df[['ID','WORKBOOKS']].explode('WORKBOOKS', ignore_index=True)
        workbooks_df = pd.concat([workbooks_df['ID'], pd.json_normalize(workbooks_df['WORKBOOKS'])], axis=1)
        workbooks_df.rename(columns={'ID':'WORKSPACEID'}, inplace=True)
        workbooks_df = generate_dataframe(workbooks_df)
        workbooks_df.dropna(subset=[c for c in workbooks_df.columns if c!='WORKSPACEID' and c!='EXTRACTEDON'], how='all', inplace=True)
        groups_df.drop(columns=['WORKBOOKS'], inplace=True)

        # Upload DataFrames to AWS S3 bucket
        my_admin.upload_dataframe_to_s3(dashboards_df, 'dashboards', 'json.gz', 'dashboards')
        my_admin.upload_dataframe_to_s3(dataflows_df, 'dataflows', 'json.gz', 'dataflows')
        my_admin.upload_dataframe_to_s3(datasets_df, 'datasets', 'json.gz', 'datasets')
        my_admin.upload_dataframe_to_s3(reports_df, 'reports', 'json.gz', 'reports')
        my_admin.upload_dataframe_to_s3(users_df, 'users', 'json.gz', 'users')
        my_admin.upload_dataframe_to_s3(workbooks_df, 'workbooks', 'json.gz', 'workbooks')
        my_admin.upload_dataframe_to_s3(groups_df, 'workspaces', 'json.gz', 'workspaces')
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()