"""
main_capacities.py

Description:
    This script pulls Power BI capacities and capacity users data and uploads it to AWS S3 bucket.

License: Proprietary - Internal Use Only

Usage:
    python main_capacities.py <configuration file>

Dependencies:
    - pbigov: For interacting with Power BI REST API
    
--------------------------------------------------------------------------------------------------
Revision History
--------------------------------------------------------------------------------------------------
Date            Developer                  Comments
--------------------------------------------------------------------------------------------------
2024-12-13      Ashleigh Wang              Initial Version
                Samir Mamedov
--------------------------------------------------------------------------------------------------
"""


import argparse
from datetime import datetime, timedelta
import logging
import os

from pbigov.admin import Admin
from pbigov.logger import setup_logger
from pbigov.utils import generate_dataframe


# Configure logger
setup_logger('capacities.log')
logger = logging.getLogger(__name__) # Logger for the current script


def main():
    """
    Main function to scan capacities metadata and upload the results to AWS S3 bucket.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Fetch data from APIs and process it.")
    parser.add_argument(
        "-c",
        "--config_file",
        type=str,
        default="config.json",
        help="Path to the configuration file, defaults to config.json"
    )
    args = parser.parse_args()
    
    if not os.path.isfile(args.config_file):
        parser.error(f"The configuration file '{args.config_file}' does not exist or is not a file.")
    
    try:
        # Create an Admin instance
        logger.info("Creating an Admin instance...")
        my_admin = Admin(args.config_file)
        
        # Get capacities and generate a DataFrame
        capacities = my_admin.get_capacities()
        logger.info("Capacities data fetched.")
        capacities_df = generate_dataframe(capacities, columns=["Id", "DisplayName", "Sku", "State", "Region"])
        
        # Track time to prevent token expiration
        start_time = datetime.now()
        
        # Get capacity users and generate a DataFrame
        columns=["ID", "GraphId", "DisplayName", "CapacityUserAccessRight"]
        capacityusers = []
        for capacity in capacities_df['ID']:
            users = my_admin.get_capacity_users(capacity)
            
            for user in users:
                capacityusers.append({'Id':capacity, **user})
            
            if datetime.now() - start_time > timedelta(hours=1):
                logger.info("Token expired. Renewing...")
                my_admin = Admin(args.config_file)

        logger.info("Users data fetched.")
        users_df = generate_dataframe(capacityusers, columns=columns).rename(columns={'CAPACITYUSERACCESSRIGHT':'ACCESSRIGHT'})

        # Upload DataFrames to AWS S3 bucket
        my_admin.upload_dataframe_to_s3(capacities_df, 'capacities', 'json.gz', 'capacities')
        my_admin.upload_dataframe_to_s3(users_df, 'capacityusers', 'json.gz', 'capacityusers')
        logger.info("DataFrames uploaded to AWS S3 bucket.")

    except Exception as e:
        logger.error(f"An error occurred: {e}", exc_info=True)


if __name__ == "__main__":
    main()