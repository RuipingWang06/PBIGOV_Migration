CREATE OR REPLACE VIEW V_DIMPBIGOV_CAPACITIES (
    ID,
    CAPACITIESNAME,
    SKU,
    STATE,
    REGION
) AS
/*
 ----------------------------------------------------------------------------------------------
 VIEW CREATED FOR PBIGOV.PBIGOV_CAPACITIES Data Load
 ----------------------------------------------------------------------------------------------
 REVISION HISTORY
 ----------------------------------------------------------------------------------------------
 DATE            DEVELOPER       COMMENTS
 ----------------------------------------------------------------------------------------------
 2025-03-04      Ashleigh Wang     INITIAL CREATION
 */
SELECT  
    ID,  
    CAPACITIESNAME,  
    SKU,  
    STATE,  
    REGION  
FROM CONFORMED.PBIGOV_CAPACITIES;