CREATE OR REPLACE VIEW V_DIMPBIGOV_CAPACITYUSERS (
    CAPACITIESID,
    GRAPHID,
    USERNAME,
    ACCESSRIGHT
) AS
/*
 ----------------------------------------------------------------------------------------------
 VIEW CREATED FOR PBIGOV.PBIGOV_CAPACITYUSERS Data Load
 ----------------------------------------------------------------------------------------------
 REVISION HISTORY
 ----------------------------------------------------------------------------------------------
 DATE            DEVELOPER       COMMENTS
 ----------------------------------------------------------------------------------------------
 2025-03-04      Ashleigh Wang     INITIAL CREATION
 */
SELECT  
    CAPACITIESID,  
    GRAPHID,  
    USERNAME,  
    ACCESSRIGHT  
FROM CONFORMED.PBIGOV_CAPACITYUSERS;