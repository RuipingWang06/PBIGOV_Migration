CREATE OR REPLACE PROCEDURE DIMPBIGOV_CAPACITYUSERS_ADD()
RETURNS VARCHAR(100)
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    result VARCHAR(100);
BEGIN
    BEGIN
        MERGE INTO PBIGOV.DIMCAPACITYUSERS AS T
        USING V_DIM_PBIGOV_CAPACITYUSERS AS S
        ON T.CAPACITIESID = S.CAPACITIESID AND T.GRAPHID = S.GRAPHID
        WHEN MATCHED THEN
            UPDATE SET 
                USERNAME = S.USERNAME,
                ACCESSRIGHT = S.ACCESSRIGHT,
                UPDATEDON = CURRENT_TIMESTAMP(),
                UPDATEDBY = CURRENT_USER()
        WHEN NOT MATCHED THEN
            INSERT (
                CAPACITIESID, 
                GRAPHID, 
                USERNAME, 
                ACCESSRIGHT, 
                CREATEDON, 
                CREATEDBY, 
                UPDATEDON, 
                UPDATEDBY
            )
            VALUES (
                S.CAPACITIESID, 
                S.GRAPHID, 
                S.USERNAME, 
                S.ACCESSRIGHT, 
                CURRENT_TIMESTAMP(), 
                CURRENT_USER(), 
                CURRENT_TIMESTAMP(), 
                CURRENT_USER()
            );
        result := 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            result := 'Failed: ' || ERROR_MESSAGE();
            CALL Admin.Error_Log_Add(
                'DIMPBIGOV_CAPACITYUSERS_ADD', 
                ERROR_CODE(), 
                ERROR_STATE(), 
                ERROR_MESSAGE(), 
                ERROR_STACK(), 
                '1'
            );
    END;
    RETURN result;
END;
$$;
