CREATE OR REPLACE PROCEDURE DIMPBIGOV_CAPACITIES_ADD()
RETURNS VARCHAR(100)
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    result VARCHAR(100);
BEGIN
    BEGIN
        MERGE INTO PBIGOV.DIMCAPACITIES AS T
        USING V_DIM_PBIGOV_CAPACITIES AS S
        ON T.ID = S.ID
        WHEN MATCHED THEN
            UPDATE SET 
                CAPACITIESNAME = S.CAPACITIESNAME,
                SKU = S.SKU,
                STATE = S.STATE,
                REGION = S.REGION,
                UPDATEDON = CURRENT_TIMESTAMP(),
                UPDATEDBY = CURRENT_USER()
        WHEN NOT MATCHED THEN
            INSERT (
                ID, 
                CAPACITIESNAME, 
                SKU, 
                STATE, 
                REGION, 
                CREATEDON, 
                CREATEDBY, 
                UPDATEDON, 
                UPDATEDBY, 
                ISDELETED
            )
            VALUES (
                S.ID, 
                S.CAPACITIESNAME, 
                S.SKU, 
                S.STATE, 
                S.REGION, 
                CURRENT_TIMESTAMP(), 
                CURRENT_USER(), 
                CURRENT_TIMESTAMP(), 
                CURRENT_USER(), 
                FALSE
            );
        UPDATE PBIGOV.DIMCAPACITIES
        SET 
            ISDELETED = TRUE,
            UPDATEDON = CURRENT_TIMESTAMP(),
            UPDATEDBY = CURRENT_USER()
        WHERE NOT EXISTS (
            SELECT 1 FROM V_DIM_PBIGOV_CAPACITIES S
            WHERE PBIGOV.DIMCAPACITIES.ID = S.ID
        );
        result := 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            result := 'Failed: ' || ERROR_MESSAGE();
            CALL Admin.Error_Log_Add(
                'DIMPBIGOV_CAPACITIES_ADD', 
                ERROR_CODE(), 
                ERROR_STATE(), 
                ERROR_MESSAGE(), 
                ERROR_STACK(), 
                '1'
            );
    END;
    RETURN result;
END;
$$;
