CREATE OR REPLACE PIPE PIPE_PBIGOV_CAPACITIES
  AUTO_INGEST = TRUE
  AS
    COPY INTO LANDING.PBIGOV_CAPACITIES
    FROM (
        SELECT 
            $1:id::VARCHAR(100),
            $1:displayname::VARCHAR(100),
            $1:sku::VARCHAR(100),
            $1:state::VARCHAR(100),
            $1:region::VARCHAR(100)
        FROM @STAGE_S3_EIP/data/pbi_gov/capacities
    )
    FILE_FORMAT = (FORMAT_NAME = 'LANDING.JSON_S3');