CREATE OR REPLACE PIPE PIPE_PBIGOV_CAPACITYUSERS
  AUTO_INGEST = TRUE
  AS
    COPY INTO LANDING.PBIGOV_CAPACITYUSERS
    FROM (
        SELECT 
            $1:id::VARCHAR(100),
            $1:graphid::VARCHAR(100),
            $1:displayname::VARCHAR(100),
            $1:accessright::VARCHAR(100)
        FROM @STAGE_S3_EIP/data/pbi_gov/capacityusers
    )
    FILE_FORMAT = (FORMAT_NAME = 'LANDING.JSON_S3');