CREATE OR REPLACE VIEW V_DIMPBIGOV_CAPACITYUSERS (
    CAPACITIESID,
    GRAPHID,
    CAPACITIESNAME,
    USERNAME,
    ACCESSRIGHT
) AS
/*
 ----------------------------------------------------------------------------------------------
 REVISION HISTORY
 ----------------------------------------------------------------------------------------------
 DATE            DEVELOPER         COMMENTS
 ----------------------------------------------------------------------------------------------
 2025-03-04      Ashleigh Wang     INITIAL CREATION
 */
SELECT  
    CU.CAPACITIESID,  
    CU.GRAPHID,  
    C.CAPACITIESNAME,  
    CU.USERNAME,  
    CU.ACCESSRIGHT  
FROM 
    PBIGOV.DIMCAPACITYUSERS CU  
    INNER JOIN PBIGOV.DIMCAPACITIES C  
        ON CU.CAPACITIESID = C.ID
WHERE 
    CU.ISDELETED = FALSE;